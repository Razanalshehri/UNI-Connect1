
  # University App

  This is a code bundle for University App. The original project is available at https://www.figma.com/design/UjGDrBqJdN7NY9V9tjMi9t/University-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  