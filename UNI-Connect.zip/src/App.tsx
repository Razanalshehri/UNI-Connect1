import { useState } from "react";
import { SplashScreen } from "./components/SplashScreen";
import { MainInterface } from "./components/MainInterface";
import { EventsPage } from "./components/EventsPage";
import { EventRegistration } from "./components/EventRegistration";
import { VotingPage } from "./components/VotingPage";
import { AcademicCalendar } from "./components/AcademicCalendar";
import { UniversityMap } from "./components/UniversityMap";
import { RequestSubmission } from "./components/RequestSubmission";
import { OfficeHours } from "./components/OfficeHours";
import { NewsPage } from "./components/NewsPage";
import { NewsDetails } from "./components/NewsDetails";
import { Toaster } from "./components/ui/sonner";

type Page = 'splash' | 'main' | 'events' | 'registration' | 'voting' | 'calendar' | 'map' | 'request' | 'office-hours' | 'news' | 'news-details';

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
}

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  content: string;
  date: string;
  category: string;
  image: string;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('splash');
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);

  const handleContinue = () => {
    setCurrentPage('main');
  };

  const handleShowNews = () => {
    setCurrentPage('news');
  };

  const handleShowEvents = () => {
    setCurrentPage('events');
  };

  const handleSelectEvent = (event: Event) => {
    setSelectedEvent(event);
    setCurrentPage('registration');
  };

  const handleBackToMain = () => {
    setCurrentPage('main');
    setSelectedEvent(null);
  };

  const handleBackToEvents = () => {
    setCurrentPage('events');
    setSelectedEvent(null);
  };

  const handleShowVoting = () => {
    setCurrentPage('voting');
  };

  const handleShowCalendar = () => {
    setCurrentPage('calendar');
  };

  const handleShowMap = () => {
    setCurrentPage('map');
  };

  const handleRegistrationSuccess = () => {
    setCurrentPage('main');
    setSelectedEvent(null);
  };

  const handleVotingSuccess = () => {
    setCurrentPage('main');
  };

  const handleShowRequest = () => {
    setCurrentPage('request');
  };

  const handleShowOfficeHours = () => {
    setCurrentPage('office-hours');
  };

  const handleRequestSuccess = () => {
    setCurrentPage('main');
  };

  const handleSelectNews = (news: NewsItem) => {
    setSelectedNews(news);
    setCurrentPage('news-details');
  };

  const handleBackToNews = () => {
    setCurrentPage('news');
    setSelectedNews(null);
  };



  if (currentPage === 'splash') {
    return <SplashScreen onContinue={handleContinue} onShowNews={handleShowNews} />;
  }

  if (currentPage === 'events') {
    return (
      <>
        <EventsPage 
          onSelectEvent={handleSelectEvent}
          onBack={handleBackToMain}
        />
        <Toaster />
      </>
    );
  }

  if (currentPage === 'registration' && selectedEvent) {
    return (
      <>
        <EventRegistration 
          event={selectedEvent}
          onBack={handleBackToEvents}
          onRegistrationSuccess={handleRegistrationSuccess}
        />
        <Toaster />
      </>
    );
  }

  if (currentPage === 'voting') {
    return (
      <>
        <VotingPage 
          onBack={handleBackToMain}
          onVotingSuccess={handleVotingSuccess}
        />
        <Toaster />
      </>
    );
  }

  if (currentPage === 'calendar') {
    return (
      <AcademicCalendar 
        onBack={handleBackToMain}
      />
    );
  }

  if (currentPage === 'map') {
    return (
      <UniversityMap 
        onBack={handleBackToMain}
      />
    );
  }

  if (currentPage === 'request') {
    return (
      <>
        <RequestSubmission 
          onBack={handleBackToMain}
          onRequestSuccess={handleRequestSuccess}
        />
        <Toaster />
      </>
    );
  }

  if (currentPage === 'office-hours') {
    return (
      <OfficeHours 
        onBack={handleBackToMain}
      />
    );
  }

  if (currentPage === 'news') {
    return (
      <NewsPage 
        onSelectNews={handleSelectNews}
        onBack={handleBackToMain}
      />
    );
  }

  if (currentPage === 'news-details' && selectedNews) {
    return (
      <NewsDetails 
        news={selectedNews}
        onBack={handleBackToNews}
      />
    );
  }



  return (
    <div className="min-h-screen">
      <MainInterface 
        onShowNews={handleShowNews}
        onShowEvents={handleShowEvents}
        onShowVoting={handleShowVoting}
        onShowCalendar={handleShowCalendar}
        onShowMap={handleShowMap}
        onShowRequest={handleShowRequest}
        onShowOfficeHours={handleShowOfficeHours}
      />
      <Toaster />
    </div>
  );
}