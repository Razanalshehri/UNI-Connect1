import { Button } from "./ui/button";
import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface SplashScreenProps {
  onContinue: () => void;
  onShowNews?: () => void;
}

export function SplashScreen({ onContinue, onShowNews }: SplashScreenProps) {
  const [currentAnnouncement, setCurrentAnnouncement] = useState(0);

  const announcements = [
    {
      id: 1,
      title: "New Academic Year 2024",
      description: "Registration is now open for all undergraduate and graduate programs. Don't miss out!",
      category: "Registration",
      date: "January 15, 2024",
      image: "https://images.unsplash.com/photo-1714194821788-6fd3634f01f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwcmVnaXN0cmF0aW9uJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU3MjY1Mjg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 2,
      title: "Digital Library Update",
      description: "Access over 10,000+ new research papers and journals in our enhanced digital library.",
      category: "Library",
      date: "January 12, 2024",
      image: "https://images.unsplash.com/photo-1674049406486-4b1f6e1845fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbGlicmFyeSUyMGJvb2tzJTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NTcyNjUyODh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 3,
      title: "Campus Innovation Center",
      description: "The new Innovation Hub opens this month with state-of-the-art facilities for student projects.",
      category: "Facilities",
      date: "January 10, 2024",
      image: "https://images.unsplash.com/photo-1722407348192-a44ce83704da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbm5vdmF0aW9uJTIwY2VudGVyJTIwdGVjaG5vbG9neSUyMGxhYnxlbnwxfHx8fDE3NTcyNjUyODh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 4,
      title: "Scholarship Opportunities",
      description: "Apply now for merit-based scholarships for the upcoming semester. Applications close soon!",
      category: "Financial Aid",
      date: "January 8, 2024",
      image: "https://images.unsplash.com/photo-1660795307991-8a7ebbef311c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2hvbGFyc2hpcCUyMGdyYWR1YXRpb24lMjBjZXJlbW9ueXxlbnwxfHx8fDE3NTcyNjUyODh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 5,
      title: "Career Fair 2024",
      description: "Meet with top employers from various industries. Network and explore career opportunities.",
      category: "Career Services",
      date: "January 5, 2024",
      image: "https://images.unsplash.com/photo-1552951131-fe0a46bb778e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJlZXIlMjBmYWlyJTIwbmV0d29ya2luZyUyMGJ1c2luZXNzfGVufDF8fHx8MTc1NzI2NTI4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentAnnouncement((prev) => (prev + 1) % announcements.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [announcements.length]);

  return (
    <div 
      className="min-h-screen flex relative overflow-hidden"
      style={{ 
        background: 'linear-gradient(135deg, #0D2E57 0%, #1e3a8a 25%, #1e40af 50%, #2563eb 75%, #3b82f6 100%)'
      }}
    >
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Floating geometric shapes */}
        <div className="absolute top-20 left-10 opacity-10">
          <svg width="80" height="80" viewBox="0 0 80 80" className="animate-float">
            <circle cx="40" cy="40" r="30" stroke="white" strokeWidth="2" fill="none" />
          </svg>
        </div>
        <div className="absolute top-1/3 right-20 opacity-10">
          <svg width="60" height="60" viewBox="0 0 60 60" className="animate-wave">
            <rect x="10" y="10" width="40" height="40" stroke="white" strokeWidth="2" fill="none" rx="8" />
          </svg>
        </div>
        <div className="absolute bottom-1/4 left-1/2 opacity-10">
          <svg width="100" height="50" viewBox="0 0 100 50" className="animate-pulse" style={{ animationDuration: '3s' }}>
            <path d="M10,25 Q30,10 50,25 Q70,40 90,25" stroke="white" strokeWidth="2" fill="none" />
          </svg>
        </div>
        
        {/* Animated particles */}
        <div className="absolute top-1/4 left-1/3 w-2 h-2 bg-white/30 rounded-full animate-ping" style={{ animationDelay: '0s' }}></div>
        <div className="absolute top-2/3 right-1/4 w-2 h-2 bg-white/20 rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-1/3 left-2/3 w-2 h-2 bg-white/40 rounded-full animate-ping" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Left Side - Announcements (40% width) */}
      <div className="w-2/5 relative z-10 p-8 flex flex-col justify-center">
        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20 shadow-2xl">
          <div className="mb-6">
            <h2 className="text-white text-2xl font-bold mb-2 animate-float">
              University Announcements
            </h2>
            <div className="h-1 bg-gradient-to-r from-white/60 to-transparent rounded-full animate-gradient"></div>
          </div>
          
          <div className="relative overflow-hidden h-96">
            {announcements.map((announcement, index) => (
              <div
                key={announcement.id}
                className={`absolute inset-0 transition-all duration-1000 ease-in-out transform ${
                  index === currentAnnouncement 
                    ? 'opacity-100 translate-y-0' 
                    : index < currentAnnouncement 
                      ? 'opacity-0 -translate-y-full' 
                      : 'opacity-0 translate-y-full'
                }`}
              >
                <div className="bg-white/20 backdrop-blur-sm rounded-2xl overflow-hidden border border-white/30 h-full flex flex-col shadow-2xl">
                  {/* Image Section */}
                  <div className="h-32 relative overflow-hidden">
                    <ImageWithFallback 
                      src={announcement.image}
                      alt={announcement.title}
                      className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    <div className="absolute top-3 left-3">
                      <span className="bg-white/90 text-[#0D2E57] text-xs px-3 py-1 rounded-full font-medium shadow-lg">
                        {announcement.category}
                      </span>
                    </div>
                    <div className="absolute top-3 right-3">
                      <span className="text-white/90 text-xs bg-black/30 backdrop-blur-sm px-2 py-1 rounded-md">
                        {announcement.date}
                      </span>
                    </div>
                  </div>
                  
                  {/* Content Section */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-white text-lg font-bold mb-3 leading-tight">
                        {announcement.title}
                      </h3>
                      <p className="text-white/90 text-sm leading-relaxed line-clamp-3">
                        {announcement.description}
                      </p>
                    </div>
                    
                    <div className="mt-4 pt-4 border-t border-white/20">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={onShowNews}
                        className="bg-white/20 text-white border-white/30 hover:bg-white hover:text-[#0D2E57] transition-all duration-300 shadow-lg hover:shadow-xl font-medium"
                      >
                        Read More →
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Announcement Navigation */}
          <div className="flex items-center justify-between mt-6">
            <button 
              onClick={() => setCurrentAnnouncement((prev) => prev === 0 ? announcements.length - 1 : prev - 1)}
              className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition-colors duration-300"
            >
              <ChevronLeft className="w-4 h-4 text-white" />
            </button>
            
            <div className="flex space-x-2">
              {announcements.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentAnnouncement(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentAnnouncement 
                      ? 'bg-white w-8' 
                      : 'bg-white/50 hover:bg-white/70'
                  }`}
                />
              ))}
            </div>
            
            <button 
              onClick={() => setCurrentAnnouncement((prev) => (prev + 1) % announcements.length)}
              className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition-colors duration-300"
            >
              <ChevronRight className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>
      </div>

      {/* Right Side - Main Content (60% width) */}
      <div className="w-3/5 relative z-10 flex flex-col items-center justify-center px-12 space-y-12">
        {/* Ministry of Education Logo - Top Right Corner */}
        <div className="absolute top-8 right-8">
          <div className="w-20 h-20 bg-white/15 backdrop-blur-sm rounded-2xl flex items-center justify-center border-2 border-white/30 shadow-xl animate-float">
            <div className="text-white text-xs text-center leading-tight font-medium">
              Ministry<br />of<br />Education
            </div>
          </div>
        </div>

        {/* University Logo with enhanced design */}
        <div className="relative group">
          <div className="w-56 h-56 bg-white/15 backdrop-blur-md rounded-full flex items-center justify-center border-4 border-white/30 shadow-2xl animate-float group-hover:scale-105 transition-all duration-700">
            <div className="text-white text-center text-xl leading-tight font-bold">
              King Abdulaziz<br />University<br />Logo
            </div>
          </div>
          {/* Decorative rings */}
          <div className="absolute inset-0 rounded-full border-2 border-white/10 scale-110 animate-pulse" style={{ animationDuration: '4s' }}></div>
          <div className="absolute inset-0 rounded-full border border-white/5 scale-125"></div>
        </div>

        {/* Main Title with enhanced typography */}
        <div className="text-center space-y-6 relative">
          {/* Background text effect */}
          <div className="absolute inset-0 text-center">
            <h1 className="text-white/5 text-7xl md:text-8xl font-bold tracking-wider transform scale-110">
              UNI CONNECT
            </h1>
          </div>
          
          {/* Main title */}
          <h1 className="text-white text-6xl md:text-7xl font-bold tracking-wider drop-shadow-2xl relative z-10 animate-gradient bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent">
            UNI CONNECT
          </h1>
          
          {/* Subtitle with glow effect */}
          <div className="relative">
            <p className="text-white/95 text-3xl md:text-4xl font-bold drop-shadow-xl animate-float">
              King Abdulaziz University
            </p>
            <p className="text-white/85 text-xl md:text-2xl font-medium mt-3 drop-shadow-lg">
              Smart Student Services Portal
            </p>
          </div>
        </div>

        {/* Enhanced GET STARTED Button */}
        <div className="relative group">
          <Button 
            onClick={onContinue}
            className="bg-white/95 text-[#0D2E57] hover:bg-white px-24 py-8 rounded-full text-3xl font-bold shadow-2xl border-4 border-white/30 transition-all duration-500 hover:scale-110 hover:shadow-white/20 relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
            <span className="relative z-10 font-bold">GET STARTED</span>
          </Button>
          {/* Button glow effect */}
          <div className="absolute inset-0 rounded-full bg-white/20 blur-xl scale-125 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        </div>

        {/* Features preview */}
        <div className="grid grid-cols-4 gap-6 mt-12 opacity-80">
          {[
            { name: 'News', icon: '📰' },
            { name: 'Events', icon: '📅' },
            { name: 'Calendar', icon: '🗓️' },
            { name: 'Map', icon: '🗺️' }
          ].map((feature) => (
            <div key={feature.name} className="text-center text-white animate-float" style={{ animationDelay: Math.random() + 's' }}>
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl mx-auto mb-3 flex items-center justify-center border border-white/30 hover:bg-white/30 transition-colors duration-300">
                <span className="text-2xl">{feature.icon}</span>
              </div>
              <p className="text-sm font-medium">{feature.name}</p>
            </div>
          ))}
        </div>
      </div>



      {/* Bottom decorative wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg width="100%" height="80" viewBox="0 0 1200 80" preserveAspectRatio="none" className="opacity-15">
          <path 
            d="M0,40 Q300,15 600,40 Q900,65 1200,40 L1200,80 L0,80 Z" 
            fill="white" 
            className="animate-pulse"
            style={{ animationDuration: '4s' }}
          />
        </svg>
      </div>
    </div>
  );
}