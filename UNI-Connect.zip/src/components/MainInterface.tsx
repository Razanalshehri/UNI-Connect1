import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { 
  Calendar, 
  MapPin, 
  Users, 
  Vote, 
  FileText, 
  Clock,
  TrendingUp,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// Enhanced news items with more data
const newsItems = [
  {
    id: 1,
    title: "King Abdulaziz University Ranks First Nationally in Global Rankings",
    summary: "Historic achievement for the university",
    category: "Achievements",
    image: "https://images.unsplash.com/photo-1563290331-f295b4fb2fd3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYXdhcmQlMjBjZXJlbW9ueXxlbnwxfHx8fDE3NTY3NDcxOTR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    isHot: true
  },
  {
    id: 2,
    title: "Graduation Ceremony for the 45th Class of University Students",
    summary: "Over 8000 graduates",
    category: "Events",
    image: "https://images.unsplash.com/photo-1738949538943-e54722a44ffc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGNlcmVtb255fGVufDF8fHx8MTc1NjY2NzQ5OXww&ixlib=rb-4.1.0&q=80&w=1080",
    isHot: false
  },
  {
    id: 3,
    title: "Strategic Partnership Agreement Signed with Harvard University",
    summary: "Distinguished academic partnership",
    category: "Partnerships",
    image: "https://images.unsplash.com/photo-1650316678805-03bcabda3f30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwaW50ZXJuYXRpb25hbCUyMHBhcnRuZXJzaGlwfGVufDF8fHx8MTc1Njc0NzIwMHww&ixlib=rb-4.1.0&q=80&w=1080",
    isHot: true
  },
  {
    id: 4,
    title: "University Student Team Wins Best Innovation Award at GITEX Global",
    summary: "Innovation in Technology Solutions",
    category: "Student Achievements",
    image: "https://images.unsplash.com/photo-1741529189563-5f3eb1253eb7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwaW5ub3ZhdGlvbiUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzU2NzQ3MjA0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    isHot: true
  },
  {
    id: 5,
    title: "New Scientific Discovery in Renewable Energy at Engineering College",
    summary: "40% increase in solar panel efficiency",
    category: "Scientific Research",
    image: "https://images.unsplash.com/photo-1659080907111-7c726e435a28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwcmVzZWFyY2glMjBhY2hpZXZlbWVudHxlbnwxfHx8fDE3NTY3NDcxOTd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    isHot: false
  }
];

// Animated News Carousel Component
function NewsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % newsItems.length);
    }, 5000); // Change every 5 seconds

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % newsItems.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000); // Resume after 10s
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + newsItems.length) % newsItems.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000); // Resume after 10s
  };

  const currentNews = newsItems[currentIndex];

  return (
    <div className="relative w-full h-full overflow-hidden group">
      <div className="w-full h-full relative">
        <div className="absolute inset-0 transition-opacity duration-1000">
          <ImageWithFallback
            src={currentNews.image}
            alt={currentNews.title}
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
          />
        </div>
        
        {/* Enhanced Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        
        {/* Hot Badge */}
        {currentNews.isHot && (
          <div className="absolute top-4 right-4 z-10">
            <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-medium animate-pulse">
              <span>HOT</span>
            </div>
          </div>
        )}

        {/* Navigation Arrows */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white/30"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white/30"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
        
        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6">
          {/* Category Badge */}
          <div className="mb-3">
            <span className="bg-blue-500/80 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium">
              {currentNews.category}
            </span>
          </div>
          
          <h3 className="text-white font-bold text-xl md:text-2xl leading-tight mb-2">
            {currentNews.title}
          </h3>
          
          <p className="text-white/90 text-sm mb-4">
            {currentNews.summary}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-white/80 text-sm">University News</span>
              <div className="w-2 h-2 bg-white/60 rounded-full"></div>
            </div>
            
            {/* Slide Indicators */}
            <div className="flex space-x-1">
              {newsItems.map((_, index) => (
                <button
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex ? 'bg-white scale-125' : 'bg-white/50'
                  }`}
                  onClick={() => {
                    setCurrentIndex(index);
                    setIsAutoPlaying(false);
                    setTimeout(() => setIsAutoPlaying(true), 10000);
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Animated Background Component
function AnimatedBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* News Background Text - Left Side Media Interface */}
      <div className="absolute left-0 top-1/2 transform -translate-y-1/2 -rotate-90 z-0">
        <div className="text-[#0D2E57]/5 text-8xl md:text-[10rem] font-bold whitespace-nowrap">
          UNIVERSITY NEWS
        </div>
      </div>
      
      {/* Secondary news text */}
      <div className="absolute left-16 top-1/4 transform -rotate-90 z-0">
        <div className="text-[#3B82F6]/3 text-5xl md:text-7xl font-bold whitespace-nowrap">
          DISTINGUISHED ACHIEVEMENTS
        </div>
      </div>

      {/* Tertiary media text */}
      <div className="absolute left-32 bottom-1/4 transform -rotate-90 z-0">
        <div className="text-[#10B981]/3 text-4xl md:text-6xl font-bold whitespace-nowrap">
          GLOBAL RANKINGS
        </div>
      </div>

      {/* Additional media branding */}
      <div className="absolute right-0 top-1/3 transform rotate-90 z-0">
        <div className="text-[#6366F1]/2 text-3xl md:text-5xl font-bold whitespace-nowrap">
          MEDIA INTERFACE
        </div>
      </div>

      {/* Media pattern overlay */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-r from-[#0D2E57]/2 via-transparent to-transparent opacity-30 z-0"></div>
      <div className="absolute bottom-0 right-0 w-full h-32 bg-gradient-to-l from-[#3B82F6]/2 via-transparent to-transparent opacity-30 z-0"></div>
      
      {/* News ticker style overlay */}
      <div className="absolute top-10 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#0D2E57]/20 to-transparent z-0"></div>
      <div className="absolute bottom-10 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#10B981]/20 to-transparent z-0"></div>

      {/* Flowing curved lines */}
      <div className="absolute top-10 left-10 opacity-10 z-0">
        <svg width="200" height="200" viewBox="0 0 200 200" className="animate-spin" style={{ animationDuration: '30s' }}>
          <path
            d="M50,50 Q100,10 150,50 T250,50"
            stroke="url(#gradient1)"
            strokeWidth="2"
            fill="none"
            className="animate-pulse"
          />
          <defs>
            <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0D2E57" />
              <stop offset="100%" stopColor="#3B82F6" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="absolute top-1/3 right-20 opacity-10 z-0">
        <svg width="150" height="150" viewBox="0 0 150 150" className="animate-bounce" style={{ animationDuration: '6s' }}>
          <path
            d="M20,20 Q75,0 130,20 Q130,75 130,130 Q75,130 20,130 Q20,75 20,20"
            stroke="url(#gradient2)"
            strokeWidth="2"
            fill="none"
          />
          <defs>
            <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#0D2E57" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="absolute bottom-20 left-1/4 opacity-10 z-0">
        <svg width="180" height="100" viewBox="0 0 180 100" className="animate-pulse" style={{ animationDuration: '4s' }}>
          <path
            d="M0,50 Q45,10 90,50 Q135,90 180,50"
            stroke="url(#gradient3)"
            strokeWidth="3"
            fill="none"
          />
          <defs>
            <linearGradient id="gradient3" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#8B5CF6" />
              <stop offset="50%" stopColor="#3B82F6" />
              <stop offset="100%" stopColor="#0D2E57" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Floating particles */}
      <div className="absolute top-1/4 left-1/3 w-2 h-2 bg-blue-400/20 rounded-full animate-ping" style={{ animationDelay: '0s', animationDuration: '3s' }}></div>
      <div className="absolute top-2/3 right-1/4 w-3 h-3 bg-green-400/20 rounded-full animate-ping" style={{ animationDelay: '1s', animationDuration: '4s' }}></div>
      <div className="absolute bottom-1/3 left-1/2 w-2 h-2 bg-purple-400/20 rounded-full animate-ping" style={{ animationDelay: '2s', animationDuration: '5s' }}></div>
    </div>
  );
}

interface MainInterfaceProps {
  onShowNews: () => void;
  onShowEvents: () => void;
  onShowVoting: () => void;
  onShowCalendar: () => void;
  onShowMap: () => void;
  onShowRequest: () => void;
  onShowOfficeHours: () => void;
}

export function MainInterface({ onShowNews, onShowEvents, onShowVoting, onShowCalendar, onShowMap, onShowRequest, onShowOfficeHours }: MainInterfaceProps) {
  return (
    <div 
      className="min-h-screen relative overflow-hidden" 
      style={{ 
        background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 25%, #e6f3ff 50%, #dbeafe 75%, #f0f9ff 100%)' 
      }}
    >
      {/* Animated Background */}
      <AnimatedBackground />
      
      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto p-4 md:p-6">
        {/* Header with curved design and media branding */}
        <div className="text-center mb-8 relative">
          <div className="absolute inset-0 flex items-center justify-center opacity-5">
            <svg width="400" height="100" viewBox="0 0 400 100">
              <path
                d="M0,50 Q100,10 200,50 Q300,90 400,50"
                stroke="#0D2E57"
                strokeWidth="4"
                fill="none"
                className="animate-pulse"
                style={{ animationDuration: '3s' }}
              />
            </svg>
          </div>
          <div className="text-4xl md:text-5xl font-bold text-[#0D2E57] relative z-10 mb-2">
            UNI Connect
          </div>
          <p className="text-lg text-gray-600 mb-1">
            King Abdulaziz University - Student Services Portal
          </p>
          <p className="text-sm text-gray-500 font-medium">
            Interactive Media Interface for University News and Achievements
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-8">
          
          {/* Left Side - Enhanced Design */}
          <div className="space-y-6">
            {/* Top Green Button with glow effect */}
            <Button 
              onClick={onShowNews}
              className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white py-8 px-8 rounded-3xl text-xl font-bold shadow-2xl transform hover:scale-105 transition-all duration-300 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-white/10 transform translate-x-full group-hover:translate-x-0 transition-transform duration-1000"></div>
              <div className="flex items-center justify-center relative z-10">
                <Users className="h-8 w-8 drop-shadow-lg mr-4" />
                <span className="drop-shadow-lg">Latest Achievement News</span>
              </div>
            </Button>

            {/* Enhanced News Carousel */}
            <Card className="h-80 lg:h-96 overflow-hidden shadow-2xl border-0 rounded-3xl relative group">
              <CardContent className="p-0 h-full">
                <NewsCarousel />
              </CardContent>
              {/* Card glow effect */}
              <div className="absolute inset-0 rounded-3xl ring-2 ring-blue-500/20 group-hover:ring-blue-500/40 transition-all duration-500"></div>
            </Card>

            {/* Bottom Buttons with enhanced design */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button 
                onClick={onShowCalendar}
                className="bg-gradient-to-br from-[#0D2E57] to-[#1e40af] hover:from-[#1e40af] hover:to-[#0D2E57] text-white py-10 px-6 rounded-3xl text-lg font-bold shadow-2xl transform hover:scale-105 transition-all duration-300 relative overflow-hidden group"
              >
                <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="flex items-center justify-center relative z-10">
                  <Calendar className="h-7 w-7 drop-shadow-lg mr-3" />
                  <span className="drop-shadow-lg">Academic Calendar</span>
                </div>
              </Button>
              
              <Button 
                onClick={onShowMap}
                className="bg-gradient-to-br from-[#0D2E57] to-[#1e40af] hover:from-[#1e40af] hover:to-[#0D2E57] text-white py-10 px-6 rounded-3xl text-lg font-bold shadow-2xl transform hover:scale-105 transition-all duration-300 relative overflow-hidden group"
              >
                <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="flex items-center justify-center relative z-10">
                  <MapPin className="h-7 w-7 drop-shadow-lg mr-3" />
                  <span className="drop-shadow-lg">University Map</span>
                </div>
              </Button>
            </div>
          </div>

          {/* Right Side - Enhanced Feature Cards */}
          <div className="space-y-6">
            {/* Feature 1: Event Participation */}
            <Card 
              className="hover:shadow-2xl transition-all duration-500 border-0 shadow-xl cursor-pointer transform hover:scale-105 rounded-3xl overflow-hidden group relative"
              onClick={onShowEvents}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <CardContent className="p-8 relative z-10">
                <div className="flex items-start">
                  <div className="p-5 bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl group-hover:from-blue-200 group-hover:to-purple-200 transition-colors duration-300 mr-6">
                    <TrendingUp className="h-8 w-8 text-gradient bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                      We Value Your Participation
                    </h3>
                    <p className="text-gray-600 text-lg leading-relaxed">
                      Join university events and student activities. Your contributions enrich the university community and help develop the educational experience for everyone.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Feature 2: Voting System */}
            <Card 
              className="hover:shadow-2xl transition-all duration-500 border-0 shadow-xl cursor-pointer transform hover:scale-105 rounded-3xl overflow-hidden group relative"
              onClick={onShowVoting}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-green-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <CardContent className="p-8 relative z-10">
                <div className="flex items-start">
                  <div className="p-5 bg-gradient-to-br from-green-100 to-blue-100 rounded-2xl group-hover:from-green-200 group-hover:to-blue-200 transition-colors duration-300 mr-6">
                    <Vote className="h-8 w-8 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                      Voting
                    </h3>
                    <p className="text-gray-600 text-lg leading-relaxed">
                      Participate in voting on important issues and decisions that affect the university community. Your opinion matters and helps us make the right decisions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Feature 3: Idea Submission */}
            <Card 
              className="hover:shadow-2xl transition-all duration-500 border-0 shadow-xl cursor-pointer transform hover:scale-105 rounded-3xl overflow-hidden group relative"
              onClick={onShowRequest}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <CardContent className="p-8 relative z-10">
                <div className="flex items-start">
                  <div className="p-5 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl group-hover:from-purple-200 group-hover:to-pink-200 transition-colors duration-300 mr-6">
                    <FileText className="h-8 w-8 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                      Submit Request
                    </h3>
                    <p className="text-gray-600 text-lg leading-relaxed">
                      Submit your ideas and suggestions to improve university services. We value your creativity and strive to implement constructive ideas that serve the university community.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Feature 4: Office Hours */}
            <Card 
              className="hover:shadow-2xl transition-all duration-500 border-0 shadow-xl cursor-pointer transform hover:scale-105 rounded-3xl overflow-hidden group relative"
              onClick={onShowOfficeHours}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <CardContent className="p-8 relative z-10">
                <div className="flex items-start">
                  <div className="p-5 bg-gradient-to-br from-orange-100 to-red-100 rounded-2xl group-hover:from-orange-200 group-hover:to-red-200 transition-colors duration-300 mr-6">
                    <Clock className="h-8 w-8 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                      Office Hours
                    </h3>
                    <p className="text-gray-600 text-lg leading-relaxed">
                      Connect with faculty members during their office hours to receive academic support and appropriate educational guidance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Footer with curved design */}
        <div className="mt-12 text-center relative">
          <div className="absolute inset-0 flex items-center justify-center opacity-5">
            <svg width="300" height="60" viewBox="0 0 300 60">
              <path
                d="M0,30 Q75,0 150,30 Q225,60 300,30"
                stroke="#0D2E57"
                strokeWidth="2"
                fill="none"
                className="animate-pulse"
                style={{ animationDuration: '4s' }}
              />
            </svg>
          </div>
          <p className="text-gray-500 relative z-10">
            King Abdulaziz University - Towards Distinguished Education and Leading Scientific Research
          </p>
        </div>
      </div>
    </div>
  );
}