import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { BookOpen, Users, MapPin, Clock } from "lucide-react";

export function Courses() {
  const enrolledCourses = [
    {
      id: 1,
      code: "CS 101",
      name: "Introduction to Computer Science",
      instructor: "Dr. Smith",
      credits: 4,
      schedule: "MWF 9:00-9:50 AM",
      location: "Science Building, Room 204",
      progress: 75,
      grade: "A-",
      students: 45,
      description: "Fundamental concepts of computer science including programming, algorithms, and data structures."
    },
    {
      id: 2,
      code: "MATH 201",
      name: "Calculus II",
      instructor: "Prof. Johnson",
      credits: 4,
      schedule: "TTh 2:00-3:30 PM",
      location: "Math Building, Room 150",
      progress: 82,
      grade: "B+",
      students: 32,
      description: "Advanced calculus topics including integration techniques, infinite series, and differential equations."
    },
    {
      id: 3,
      code: "PHYS 150",
      name: "General Physics I",
      instructor: "Dr. Brown",
      credits: 4,
      schedule: "MWF 4:00-5:30 PM",
      location: "Physics Building, Lab 301",
      progress: 68,
      grade: "B",
      students: 28,
      description: "Classical mechanics, thermodynamics, and wave motion with laboratory experiments."
    },
    {
      id: 4,
      code: "ENG 102",
      name: "English Literature",
      instructor: "Prof. Davis",
      credits: 3,
      schedule: "TTh 11:00-12:30 PM",
      location: "Liberal Arts, Room 210",
      progress: 90,
      grade: "A",
      students: 25,
      description: "Survey of British and American literature from the 18th century to present."
    }
  ];

  const availableCourses = [
    {
      id: 5,
      code: "CS 201",
      name: "Data Structures",
      instructor: "Dr. Wilson",
      credits: 4,
      schedule: "MWF 10:00-10:50 AM",
      location: "Science Building, Room 205",
      students: 30,
      maxStudents: 40,
      description: "Advanced data structures and algorithms including trees, graphs, and dynamic programming."
    },
    {
      id: 6,
      code: "HIST 101",
      name: "World History",
      instructor: "Prof. Taylor",
      credits: 3,
      schedule: "TTh 1:00-2:30 PM",
      location: "Liberal Arts, Room 110",
      students: 18,
      maxStudents: 35,
      description: "Survey of world civilizations from ancient times to the modern era."
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>My Courses</h1>
          <p className="text-muted-foreground">Manage your enrolled courses and explore new ones.</p>
        </div>
        <Badge variant="secondary">Fall 2025</Badge>
      </div>

      <div className="space-y-4">
        <h2>Enrolled Courses</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {enrolledCourses.map((course) => (
            <Card key={course.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <span>{course.code}</span>
                      <Badge variant="outline">{course.credits} credits</Badge>
                    </CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">{course.name}</p>
                  </div>
                  <Badge variant={course.grade.startsWith('A') ? 'default' : course.grade.startsWith('B') ? 'secondary' : 'outline'}>
                    {course.grade}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm">{course.description}</p>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                    <span>{course.instructor}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{course.schedule}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{course.location}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{course.students} students</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Course Progress</span>
                    <span>{course.progress}%</span>
                  </div>
                  <Progress value={course.progress} className="h-2" />
                </div>

                <Button variant="outline" size="sm" className="w-full">
                  View Course Details
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h2>Available Courses</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {availableCourses.map((course) => (
            <Card key={course.id}>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span>{course.code}</span>
                  <Badge variant="outline">{course.credits} credits</Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">{course.name}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm">{course.description}</p>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                    <span>{course.instructor}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{course.schedule}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{course.location}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{course.students}/{course.maxStudents} students</span>
                  </div>
                </div>

                <div className="flex space-x-2">  
                  <Button size="sm" className="flex-1">
                    Enroll Now
                  </Button>
                  <Button variant="outline" size="sm">
                    Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}