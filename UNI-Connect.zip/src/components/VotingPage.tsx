import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { ArrowLeft, Vote, Users, Calendar, Trophy, BookOpen, Palette } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface VotingPageProps {
  onBack: () => void;
  onVotingSuccess: () => void;
}

const colleges = [
  "College of Engineering",
  "College of Computer Science and Information Technology", 
  "College of Business Administration",
  "College of Medicine",
  "College of Science",
  "College of Arts and Humanities",
  "College of Education",
  "College of Law",
  "College of Pharmacy",
  "College of Dentistry"
];

const proposedEvents = [
  {
    id: "1",
    title: "International Cultures Festival",
    description: "An event showcasing different cultures through food, music, and arts",
    proposedBy: "International Students Association",
    icon: Palette,
    votes: 234
  },
  {
    id: "2", 
    title: "University Sports Day",
    description: "A comprehensive sports day with various competitions for students",
    proposedBy: "Sports Club",
    icon: Trophy,
    votes: 189
  },
  {
    id: "3",
    title: "Student Entrepreneurship Workshop",
    description: "Intensive training workshop on entrepreneurship skills and investment",
    proposedBy: "Entrepreneurship Club",
    icon: Users,
    votes: 156
  },
  {
    id: "4",
    title: "Graduation Projects Exhibition",
    description: "Annual exhibition showcasing the best graduation projects from all colleges",
    proposedBy: "Deanship of Student Affairs",
    icon: BookOpen,
    votes: 298
  },
  {
    id: "5",
    title: "Technology and Future Conference",
    description: "Conference discussing the latest technological developments and their impact on the future",
    proposedBy: "Computer Students Association",
    icon: Calendar,
    votes: 167
  }
];

export function VotingPage({ onBack, onVotingSuccess }: VotingPageProps) {
  const [selectedEvent, setSelectedEvent] = useState<string>("");
  const [selectedCollege, setSelectedCollege] = useState<string>("");
  const [studentId, setStudentId] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedEvent || !selectedCollege || !studentId) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (studentId.length !== 9) {
      toast.error("Student ID must be exactly 9 digits");
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success("Your vote has been successfully recorded!");
      
      // Reset form
      setSelectedEvent("");
      setSelectedCollege("");
      setStudentId("");
      
      // Return to main page after a short delay
      setTimeout(() => {
        toast.info("Redirecting to main page...");
        setTimeout(() => {
          onVotingSuccess();
        }, 800);
      }, 1500);
    }, 2000);
  };

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-6xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold text-[#0D2E57]">
            Vote on Proposed Events
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Proposed Events List */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-[#0D2E57] flex items-center">
                  <Vote className="h-6 w-6 mr-3" />
                  <span>Student Proposed Events</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <RadioGroup value={selectedEvent} onValueChange={setSelectedEvent}>
                  {proposedEvents.map((event) => {
                    const IconComponent = event.icon;
                    return (
                      <div 
                        key={event.id}
                        className={`flex items-start p-4 rounded-lg border-2 transition-all duration-200 cursor-pointer hover:shadow-md ${
                          selectedEvent === event.id 
                            ? 'border-[#0D2E57] bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedEvent(event.id)}
                      >
                        <RadioGroupItem value={event.id} id={event.id} className="mt-1 mr-4" />
                        <div className="flex-1 space-y-2">
                          <div className="flex items-start">
                            <div className="p-2 bg-[#0D2E57] rounded-lg mr-4">
                              <IconComponent className="h-5 w-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <Label 
                                htmlFor={event.id}
                                className="text-lg font-semibold cursor-pointer block"
                              >
                                {event.title}
                              </Label>
                              <p className="text-gray-600 text-sm leading-relaxed mt-1">
                                {event.description}
                              </p>
                              <div className="flex items-center justify-between mt-3">
                                <p className="text-xs text-gray-500">
                                  Proposed by: {event.proposedBy}
                                </p>
                                <div className="flex items-center">
                                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                                  <span className="text-xs text-gray-500">
                                    {event.votes} votes
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </RadioGroup>
              </CardContent>
            </Card>
          </div>

          {/* Voting Form */}
          <div className="lg:col-span-1">
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle className="text-xl text-[#0D2E57]">
                  Voting Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <p className="text-gray-600 leading-relaxed">
                    Please register your information to validate your vote and ensure participation accuracy
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* College Selection */}
                  <div className="space-y-2">
                    <Label className="block">
                      Select Your College *
                    </Label>
                    <Select value={selectedCollege} onValueChange={setSelectedCollege}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Choose your college" />
                      </SelectTrigger>
                      <SelectContent>
                        {colleges.map((college, index) => (
                          <SelectItem key={index} value={college}>
                            {college}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Student ID */}
                  <div className="space-y-2">
                    <Label className="block">
                      Student ID *
                    </Label>
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={studentId}
                      onChange={(e) => {
                        // Only allow numbers
                        const value = e.target.value.replace(/[^0-9]/g, '');
                        setStudentId(value);
                      }}
                      onKeyPress={(e) => {
                        // Prevent non-numeric characters
                        if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'Tab') {
                          e.preventDefault();
                        }
                      }}
                      placeholder="Enter your student ID (numbers only)"
                      maxLength={9}
                    />
                  </div>

                  {/* Info Note */}
                  <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                    <p className="text-yellow-800 text-sm leading-relaxed">
                      <strong>Note:</strong> Each student can vote only once. Student ID will be verified to prevent duplicate voting.
                    </p>
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit"
                    disabled={isSubmitting || !selectedEvent || !selectedCollege || !studentId}
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        <span>Submitting...</span>
                      </span>
                    ) : (
                      <span>Submit Vote</span>
                    )}
                  </Button>

                  <p className="text-xs text-gray-500 text-center leading-relaxed">
                    By clicking "Submit Vote", you confirm the accuracy of the entered data and agree to the voting terms
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}