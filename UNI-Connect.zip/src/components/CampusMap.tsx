import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { 
  Search, 
  MapPin, 
  Navigation, 
  Phone, 
  Clock, 
  Users,
  Building,
  Car,
  Coffee,
  BookOpen,
  Utensils,
  GraduationCap
} from "lucide-react";

export function CampusMap() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBuilding, setSelectedBuilding] = useState<any>(null);

  const buildings = [
    {
      id: 1,
      name: "Main Library",
      category: "Academic",
      description: "Central library with study spaces and computer labs",
      location: "Building A, Zone 1",
      hours: "Mon-Fri: 8 AM - 10 PM, Sat-Sun: 10 AM - 8 PM",
      phone: "(555) 123-4567",
      services: ["Study Rooms", "Computer Lab", "Printing", "WiFi"],
      icon: BookOpen,
      coordinates: { x: 40, y: 30 },
      isOpen: true
    },
    {
      id: 2,
      name: "Student Center",
      category: "Student Life",
      description: "Hub for student activities and dining",
      location: "Building B, Zone 2",
      hours: "Mon-Fri: 7 AM - 11 PM, Sat-Sun: 9 AM - 11 PM",
      phone: "(555) 234-5678",
      services: ["Food Court", "Student Services", "ATM", "Lounge"],
      icon: Users,
      coordinates: { x: 60, y: 50 },
      isOpen: true
    },
    {
      id: 3,
      name: "Science Building",
      category: "Academic",
      description: "Laboratories and lecture halls for science courses",
      location: "Building C, Zone 1",
      hours: "Mon-Fri: 7 AM - 9 PM, Sat: 9 AM - 5 PM",
      phone: "(555) 345-6789",
      services: ["Labs", "Lecture Halls", "Equipment Rental"],
      icon: GraduationCap,
      coordinates: { x: 30, y: 60 },
      isOpen: true
    },
    {
      id: 4,
      name: "Parking Garage A",
      category: "Parking",
      description: "Multi-level parking facility",
      location: "Zone 3",
      hours: "24/7 Access",
      phone: "N/A",
      services: ["Car Parking", "EV Charging", "Security"],
      icon: Car,
      coordinates: { x: 15, y: 40 },
      isOpen: true
    },
    {
      id: 5,
      name: "Campus Cafe",
      category: "Dining",
      description: "Coffee shop and light meals",
      location: "Ground Floor, Student Center",
      hours: "Mon-Fri: 6 AM - 8 PM, Sat-Sun: 8 AM - 6 PM",
      phone: "(555) 456-7890",
      services: ["Coffee", "Pastries", "Sandwiches", "WiFi"],
      icon: Coffee,
      coordinates: { x: 58, y: 48 },
      isOpen: false
    },
    {
      id: 6,
      name: "Administration Building",
      category: "Administrative",
      description: "University administrative offices",
      location: "Building D, Zone 1",
      hours: "Mon-Fri: 8 AM - 5 PM",
      phone: "(555) 567-8901",
      services: ["Registrar", "Financial Aid", "Admissions"],
      icon: Building,
      coordinates: { x: 70, y: 25 },
      isOpen: false
    }
  ];

  const filteredBuildings = buildings.filter(building =>
    building.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    building.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    building.services.some(service => service.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Academic": return "bg-blue-100 text-blue-800 border-blue-200";
      case "Student Life": return "bg-green-100 text-green-800 border-green-200";
      case "Dining": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Parking": return "bg-gray-100 text-gray-800 border-gray-200";
      case "Administrative": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="pb-20 space-y-6">
      {/* Header */}
      <div className="px-4 pt-4">
        <h1 className="mb-2">Campus Map</h1>
        <p className="text-muted-foreground text-sm mb-4">
          Navigate your campus with interactive map and location services
        </p>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search buildings, services, or locations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Interactive Map */}
      <div className="px-4">
        <Card className="overflow-hidden">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Interactive Campus Map</CardTitle>
              <Button size="sm" variant="outline">
                <Navigation className="h-4 w-4 mr-2" />
                Navigate
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="relative bg-green-50 h-64 overflow-hidden">
              {/* Simplified campus map background */}
              <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-blue-100">
                {/* Paths */}
                <svg className="absolute inset-0 w-full h-full">
                  <path
                    d="M20,100 Q150,50 280,120"
                    stroke="#94a3b8"
                    strokeWidth="3"
                    fill="none"
                    strokeDasharray="5,5"
                  />
                  <path
                    d="M50,200 L250,200 L250,50"
                    stroke="#94a3b8"
                    strokeWidth="3"
                    fill="none"
                  />
                </svg>
                
                {/* Building markers */}
                {buildings.map((building) => {
                  const IconComponent = building.icon;
                  return (
                    <button
                      key={building.id}
                      onClick={() => setSelectedBuilding(building)}
                      className={`absolute transform -translate-x-1/2 -translate-y-1/2 p-2 rounded-full shadow-lg transition-all hover:scale-110 ${
                        building.isOpen 
                          ? "bg-primary text-primary-foreground" 
                          : "bg-gray-400 text-white"
                      } ${selectedBuilding?.id === building.id ? "ring-4 ring-primary/30 scale-110" : ""}`}
                      style={{ 
                        left: `${building.coordinates.x}%`, 
                        top: `${building.coordinates.y}%` 
                      }}
                    >
                      <IconComponent className="h-4 w-4" />
                    </button>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Selected Building Details */}
      {selectedBuilding && (
        <div className="px-4">
          <Card className="border-primary/50">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-base">{selectedBuilding.name}</CardTitle>
                  <Badge className={getCategoryColor(selectedBuilding.category) + " mt-1"}>
                    {selectedBuilding.category}
                  </Badge>
                </div>
                <Badge variant={selectedBuilding.isOpen ? "default" : "secondary"}>
                  {selectedBuilding.isOpen ? "Open" : "Closed"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{selectedBuilding.description}</p>
              
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedBuilding.location}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedBuilding.hours}</span>
                </div>
                {selectedBuilding.phone !== "N/A" && (
                  <div className="flex items-center space-x-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedBuilding.phone}</span>
                  </div>
                )}
              </div>

              <div>
                <h4 className="font-medium mb-2">Available Services</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedBuilding.services.map((service, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {service}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2">
                <Button size="sm" className="flex-1">
                  <Navigation className="h-4 w-4 mr-2" />
                  Get Directions
                </Button>
                {selectedBuilding.phone !== "N/A" && (
                  <Button size="sm" variant="outline">
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Buildings List */}
      <div className="px-4">
        <h2 className="mb-4">Campus Buildings</h2>
        <div className="space-y-3">
          {filteredBuildings.map((building) => {
            const IconComponent = building.icon;
            return (
              <Card 
                key={building.id} 
                className={`cursor-pointer hover:border-primary/50 transition-colors ${
                  selectedBuilding?.id === building.id ? "border-primary/50 bg-primary/5" : ""
                }`}
                onClick={() => setSelectedBuilding(building)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${building.isOpen ? "bg-primary text-primary-foreground" : "bg-gray-100"}`}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-medium">{building.name}</h3>
                        <Badge variant={building.isOpen ? "default" : "secondary"} className="text-xs">
                          {building.isOpen ? "Open" : "Closed"}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{building.description}</p>
                      <div className="flex items-center justify-between mt-2">
                        <Badge className={getCategoryColor(building.category) + " text-xs"}>
                          {building.category}
                        </Badge>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <MapPin className="h-3 w-3 mr-1" />
                          {building.location}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4">
        <h2 className="mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-4">
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <Car className="h-6 w-6 text-primary" />
            <span className="text-sm">Find Parking</span>
          </Button>
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <Utensils className="h-6 w-6 text-primary" />
            <span className="text-sm">Nearby Dining</span>
          </Button>
        </div>
      </div>
    </div>
  );
}