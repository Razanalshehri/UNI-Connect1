import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Calendar, Clock, MapPin, Users, Heart } from "lucide-react";

export function Events() {
  const upcomingEvents = [
    {
      id: 1,
      title: "Tech Innovation Summit",
      description: "Explore the latest in technology and innovation with industry leaders.",
      date: "2025-09-10",
      time: "2:00 PM - 6:00 PM",
      location: "Main Auditorium",
      category: "Academic",
      attendees: 156,
      maxAttendees: 300,
      image: "https://images.unsplash.com/photo-1693011142814-aa33d7d1535c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU2NjQ2NjMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      isRegistered: false
    },
    {
      id: 2,
      title: "Fall Career Fair",
      description: "Meet with top employers and explore internship and job opportunities.",
      date: "2025-09-15",
      time: "10:00 AM - 4:00 PM",
      location: "Student Union Building",
      category: "Career",
      attendees: 250,
      maxAttendees: 500,
      image: "https://images.unsplash.com/photo-1693011142814-aa33d7d1535c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU2NjQ2NjMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      isRegistered: false
    },
    {
      id: 2,
      title: "Science Symposium",
      description: "Student research presentations and keynote speakers in STEM fields.",
      date: "2025-09-20",
      time: "9:00 AM - 5:00 PM",
      location: "Science Building Auditorium",
      category: "Academic",
      attendees: 120,
      maxAttendees: 200,
      image: "https://images.unsplash.com/photo-1693011142814-aa33d7d1535c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU2NjQ2NjMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      isRegistered: true
    },
    {
      id: 3,
      title: "Welcome Week BBQ",
      description: "Join us for food, games, and meeting new friends on campus.",
      date: "2025-09-08",
      time: "12:00 PM - 4:00 PM",
      location: "Campus Quad",
      category: "Social",
      attendees: 180,
      maxAttendees: 300,
      image: "https://images.unsplash.com/photo-1693011142814-aa33d7d1535c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU2NjQ2NjMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      isRegistered: false
    },
    {
      id: 4,
      title: "Guest Lecture: AI in Healthcare",
      description: "Renowned researcher Dr. Jane Smith discusses the future of AI in medicine.",
      date: "2025-09-25",
      time: "7:00 PM - 8:30 PM",
      location: "Medical Center, Room 101",
      category: "Academic",
      attendees: 85,
      maxAttendees: 150,
      image: "https://images.unsplash.com/photo-1693011142814-aa33d7d1535c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU2NjQ2NjMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      isRegistered: false
    }
  ];

  const registeredEvents = upcomingEvents.filter(event => event.isRegistered);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Career": return "bg-blue-100 text-blue-800 border-blue-200";
      case "Academic": return "bg-green-100 text-green-800 border-green-200";
      case "Social": return "bg-purple-100 text-purple-800 border-purple-200";
      case "Sports": return "bg-orange-100 text-orange-800 border-orange-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="pb-20 space-y-6">
      <div className="px-4 pt-4">
        <div className="flex items-center justify-between mb-2">
          <h1>Campus Events</h1>
          <Button size="sm">
            Create Event
          </Button>
        </div>
        <p className="text-muted-foreground text-sm">
          Discover and join exciting events happening on campus.
        </p>
      </div>

      {registeredEvents.length > 0 && (
        <div className="px-4 space-y-4">
          <h2>My Registered Events</h2>
          <div className="space-y-4">
            {registeredEvents.map((event) => (
              <Card key={event.id} className="border-primary/20">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <Badge className={getCategoryColor(event.category)}>
                      {event.category}
                    </Badge>
                    <Badge variant="outline" className="text-green-700 border-green-200">
                      Registered
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <h3>{event.title}</h3>
                    <p className="text-sm text-muted-foreground">{event.description}</p>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{formatDate(event.date)}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{event.location}</span>
                    </div>
                  </div>

                  <Button variant="outline" size="sm" className="w-full">
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <div className="px-4 space-y-4">
        <h2>Upcoming Events</h2>
        <div className="space-y-4">
          {upcomingEvents.map((event) => (
            <Card key={event.id} className="overflow-hidden">
              <div className="relative">
                <ImageWithFallback
                  src={event.image}
                  alt={event.title}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-2 left-2">
                  <Badge className={getCategoryColor(event.category)}>
                    {event.category}
                  </Badge>
                </div>
                {event.isRegistered && (
                  <div className="absolute top-2 right-2">
                    <Badge variant="outline" className="text-green-700 border-green-200 bg-white">
                      Registered
                    </Badge>
                  </div>
                )}
              </div>
              
              <CardContent className="p-4 space-y-3">
                <div>
                  <h3>{event.title}</h3>
                  <p className="text-sm text-muted-foreground">{event.description}</p>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{formatDate(event.date)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{event.attendees}/{event.maxAttendees} registered</span>
                  </div>
                </div>

                <div className="flex space-x-2">
                  {event.isRegistered ? (
                    <Button variant="outline" size="sm" className="flex-1">
                      View Details
                    </Button>
                  ) : (
                    <>
                      <Button size="sm" className="flex-1">
                        Register
                      </Button>
                      <Button variant="outline" size="sm">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="px-4">
        <Card>
          <CardHeader>
            <CardTitle>Event Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">15</div>
                <div className="text-sm text-blue-700">Career Events</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">22</div>
                <div className="text-sm text-green-700">Academic Events</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">18</div>
                <div className="text-sm text-purple-700">Social Events</div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">12</div>
                <div className="text-sm text-orange-700">Sports Events</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}