import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Edit, Mail, Phone, MapPin, Calendar, GraduationCap, Award } from "lucide-react";

export function Profile() {
  const studentInfo = {
    name: "Sarah Johnson",
    email: "sarah.johnson@university.edu",
    phone: "(555) 123-4567",
    studentId: "SU2024001234",
    major: "Computer Science",
    minor: "Mathematics",
    year: "Junior",
    expectedGraduation: "Spring 2026",
    gpa: 3.74,
    credits: 90,
    address: "123 Campus Drive, Apt 4B, University City, ST 12345",
    emergencyContact: {
      name: "Michael Johnson",
      relationship: "Father",
      phone: "(555) 987-6543"
    },
    profileImage: "https://images.unsplash.com/photo-1568880893176-fb2bdab44e41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwcHJvZmlsZSUyMHBob3RvfGVufDF8fHx8MTc1NjY2MDI2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  };

  const achievements = [
    { title: "Dean's List", semester: "Fall 2024", description: "Achieved GPA above 3.5" },
    { title: "Programming Competition Winner", date: "March 2024", description: "1st place in regional coding contest" },
    { title: "Research Assistant", period: "2024-Present", description: "CS Department research on machine learning" }
  ];

  const activities = [
    { name: "Computer Science Club", role: "Vice President", year: "2024-2025" },
    { name: "Math Tutoring Center", role: "Tutor", year: "2023-2024" },
    { name: "University Orchestra", role: "Violinist", year: "2022-Present" }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Student Profile</h1>
          <p className="text-muted-foreground">Manage your personal information and academic details.</p>
        </div>
        <Button>
          <Edit className="h-4 w-4 mr-2" />
          Edit Profile
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-6 text-center">
              <ImageWithFallback
                src={studentInfo.profileImage}
                alt={studentInfo.name}
                className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
              />
              <h2 className="mb-2">{studentInfo.name}</h2>
              <p className="text-muted-foreground mb-4">{studentInfo.studentId}</p>
              
              <div className="space-y-2 text-sm">
                <Badge variant="secondary" className="mr-2">{studentInfo.year}</Badge>
                <Badge variant="outline">{studentInfo.major}</Badge>
              </div>

              <div className="mt-4 pt-4 border-t space-y-2 text-sm">
                <div className="flex items-center justify-center space-x-2">
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                  <span>GPA: {studentInfo.gpa}</span>
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Graduating {studentInfo.expectedGraduation}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Completed Credits</span>
                <span className="font-medium">{studentInfo.credits}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Current GPA</span>
                <span className="font-medium">{studentInfo.gpa}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Academic Year</span>
                <span className="font-medium">{studentInfo.year}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Major</span>
                <span className="font-medium">{studentInfo.major}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" value={studentInfo.name} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="studentId">Student ID</Label>
                  <Input id="studentId" value={studentInfo.studentId} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" value={studentInfo.email} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" value={studentInfo.phone} />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea id="address" value={studentInfo.address} rows={2} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Academic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="major">Major</Label>
                  <Input id="major" value={studentInfo.major} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="minor">Minor</Label>
                  <Input id="minor" value={studentInfo.minor} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year">Academic Year</Label>
                  <Input id="year" value={studentInfo.year} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="graduation">Expected Graduation</Label>
                  <Input id="graduation" value={studentInfo.expectedGraduation} readOnly />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Emergency Contact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="emergencyName">Name</Label>
                  <Input id="emergencyName" value={studentInfo.emergencyContact.name} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="relationship">Relationship</Label>
                  <Input id="relationship" value={studentInfo.emergencyContact.relationship} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emergencyPhone">Phone</Label>
                  <Input id="emergencyPhone" value={studentInfo.emergencyContact.phone} />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="h-5 w-5" />
                  <span>Achievements</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {achievements.map((achievement, index) => (
                  <div key={index} className="p-3 bg-secondary/50 rounded-lg">
                    <h4 className="font-medium">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground">
                      {achievement.semester || achievement.date || achievement.period}
                    </p>
                    <p className="text-sm mt-1">{achievement.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Activities & Organizations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {activities.map((activity, index) => (
                  <div key={index} className="p-3 bg-secondary/50 rounded-lg">
                    <h4 className="font-medium">{activity.name}</h4>
                    <p className="text-sm text-muted-foreground">{activity.role}</p>
                    <p className="text-sm mt-1">{activity.year}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}