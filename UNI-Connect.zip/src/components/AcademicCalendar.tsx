import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Calendar } from "./ui/calendar";
import { Badge } from "./ui/badge";
import { ArrowRight, Calendar as CalendarIcon, Clock, MapPin, AlertCircle } from "lucide-react";

interface AcademicCalendarProps {
  onBack: () => void;
}

interface AcademicEvent {
  id: string;
  title: string;
  date: Date;
  type: 'exam' | 'holiday' | 'registration' | 'event' | 'deadline';
  description?: string;
  location?: string;
  time?: string;
}

// Mock academic events data
const academicEvents: AcademicEvent[] = [
  {
    id: "1",
    title: "Start of Spring Semester",
    date: new Date(2024, 1, 11), // February 11, 2024
    type: "event",
    description: "Beginning of classes for the Spring semester",
    time: "08:00 AM"
  },
  {
    id: "2", 
    title: "Add/Drop Period Ends",
    date: new Date(2024, 1, 25), // February 25, 2024
    type: "deadline",
    description: "Last day to add or drop courses",
    time: "11:59 PM"
  },
  {
    id: "3",
    title: "Midterm Examinations",
    date: new Date(2024, 2, 15), // March 15, 2024
    type: "exam",
    description: "Midterm examination period",
    time: "09:00 AM"
  },
  {
    id: "4",
    title: "Spring Break",
    date: new Date(2024, 3, 10), // April 10, 2024
    type: "holiday",
    description: "Spring break holiday period",
    time: "All Day"
  },
  {
    id: "5",
    title: "Summer Session Registration",
    date: new Date(2024, 3, 20), // April 20, 2024
    type: "registration",
    description: "Start of Summer session registration",
    time: "09:00 AM"
  },
  {
    id: "6",
    title: "Final Examinations",
    date: new Date(2024, 4, 5), // May 5, 2024
    type: "exam",
    description: "Beginning of final examination period",
    time: "09:00 AM"
  },
  {
    id: "7",
    title: "End of Spring Semester",
    date: new Date(2024, 4, 20), // May 20, 2024
    type: "event",
    description: "End of Spring semester classes",
    time: "05:00 PM"
  }
];

const eventTypeColors = {
  exam: "bg-red-100 text-red-800 border-red-200",
  holiday: "bg-green-100 text-green-800 border-green-200", 
  registration: "bg-blue-100 text-blue-800 border-blue-200",
  event: "bg-purple-100 text-purple-800 border-purple-200",
  deadline: "bg-orange-100 text-orange-800 border-orange-200"
};

const eventTypeLabels = {
  exam: "Exam",
  holiday: "Holiday",
  registration: "Registration", 
  event: "Event",
  deadline: "Deadline"
};

export function AcademicCalendar({ onBack }: AcademicCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedEvent, setSelectedEvent] = useState<AcademicEvent | null>(null);

  // Get events for selected date
  const getEventsForDate = (date: Date) => {
    return academicEvents.filter(event => 
      event.date.toDateString() === date.toDateString()
    );
  };

  // Get all upcoming events (next 30 days)
  const getUpcomingEvents = () => {
    const today = new Date();
    const thirtyDaysLater = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);
    
    return academicEvents
      .filter(event => event.date >= today && event.date <= thirtyDaysLater)
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  };

  const selectedDateEvents = selectedDate ? getEventsForDate(selectedDate) : [];
  const upcomingEvents = getUpcomingEvents();

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center"
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold text-[#0D2E57] flex items-center">
            <CalendarIcon className="h-8 w-8 mr-4" />
            <span>Academic Calendar</span>
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-[#0D2E57]">
                  Spring Semester 2024
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border w-full"
                  classNames={{
                    months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
                    month: "space-y-4 w-full",
                    caption: "flex justify-center pt-1 relative items-center",
                    caption_label: "text-sm font-medium",
                    nav: "space-x-1 flex items-center",
                    nav_button: "h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100",
                    nav_button_previous: "absolute left-1",
                    nav_button_next: "absolute right-1",
                    table: "w-full border-collapse space-y-1",
                    head_row: "flex",
                    head_cell: "text-muted-foreground rounded-md w-9 font-normal text-[0.8rem]",
                    row: "flex w-full mt-2",
                    cell: "relative p-0 text-center text-sm focus-within:relative focus-within:z-20 [&:has([aria-selected])]:bg-accent [&:has([aria-selected].day-outside)]:bg-accent/50 [&:has([aria-selected].day-range-end)]:rounded-r-md",
                    day: "h-9 w-9 p-0 font-normal aria-selected:opacity-100",
                    day_range_end: "day-range-end",
                    day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
                    day_today: "bg-accent text-accent-foreground",
                    day_outside: "day-outside text-muted-foreground opacity-50 aria-selected:bg-accent/50 aria-selected:text-muted-foreground aria-selected:opacity-30",
                    day_disabled: "text-muted-foreground opacity-50",
                    day_range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
                    day_hidden: "invisible",
                  }}
                  modifiers={{
                    eventDay: academicEvents.map(event => event.date)
                  }}
                  modifiersClassNames={{
                    eventDay: "bg-blue-100 text-blue-900 font-semibold"
                  }}
                />

                {/* Legend */}
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-3">Color Legend:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {Object.entries(eventTypeLabels).map(([type, label]) => (
                      <div key={type} className="flex items-center">
                        <div className={`w-3 h-3 rounded-full ${eventTypeColors[type as keyof typeof eventTypeColors].split(' ')[0]} mr-2`}></div>
                        <span className="text-sm">{label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Events List */}
          <div className="lg:col-span-1 space-y-6">
            {/* Selected Date Events */}
            {selectedDate && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-[#0D2E57]">
                    Events on {selectedDate.toLocaleDateString('en-US')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedDateEvents.length > 0 ? (
                    <div className="space-y-3">
                      {selectedDateEvents.map((event) => (
                        <div 
                          key={event.id}
                          className="p-3 border rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => setSelectedEvent(event)}
                        >
                          <div className="flex items-start justify-between space-x-2">
                            <Badge className={`${eventTypeColors[event.type]} text-xs`}>
                              {eventTypeLabels[event.type]}
                            </Badge>
                          </div>
                          <h4 className="font-medium mt-2">{event.title}</h4>
                          {event.time && (
                            <div className="flex items-center mt-1">
                              <Clock className="h-3 w-3 text-gray-400 mr-2" />
                              <span className="text-xs text-gray-500">{event.time}</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">
                      No events on this date
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Upcoming Events */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-[#0D2E57] flex items-center">
                  <AlertCircle className="h-5 w-5 mr-3" />
                  <span>Upcoming Events</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingEvents.map((event) => (
                    <div 
                      key={event.id}
                      className="p-3 border rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setSelectedEvent(event)}
                    >
                      <div className="flex items-start justify-between space-x-2">
                        <Badge className={`${eventTypeColors[event.type]} text-xs`}>
                          {eventTypeLabels[event.type]}
                        </Badge>
                      </div>
                      <h4 className="font-medium mt-2">{event.title}</h4>
                      <div className="flex items-center mt-1">
                        <CalendarIcon className="h-3 w-3 text-gray-400 mr-2" />
                        <span className="text-xs text-gray-500">
                          {event.date.toLocaleDateString('en-US')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Event Details Modal */}
        {selectedEvent && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-md">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-[#0D2E57]">
                    Event Details
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedEvent(null)}
                  >
                    ✕
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Badge className={`${eventTypeColors[selectedEvent.type]} mb-2`}>
                    {eventTypeLabels[selectedEvent.type]}
                  </Badge>
                  <h3 className="font-semibold text-lg">
                    {selectedEvent.title}
                  </h3>
                </div>
                
                {selectedEvent.description && (
                  <p className="text-gray-600 leading-relaxed">
                    {selectedEvent.description}
                  </p>
                )}

                <div className="space-y-2">
                  <div className="flex items-center">
                    <CalendarIcon className="h-4 w-4 text-gray-500 mr-2" />
                    <span className="text-sm">
                      {selectedEvent.date.toLocaleDateString('en-US')}
                    </span>
                  </div>
                  
                  {selectedEvent.time && (
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-sm">
                        {selectedEvent.time}
                      </span>
                    </div>
                  )}

                  {selectedEvent.location && (
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-sm">
                        {selectedEvent.location}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}