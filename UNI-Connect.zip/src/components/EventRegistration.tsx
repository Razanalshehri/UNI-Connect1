import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { ArrowLeft, Calendar, MapPin, CheckCircle } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
}

interface EventRegistrationProps {
  event: Event;
  onBack: () => void;
  onRegistrationSuccess: () => void;
}

const colleges = [
  "College of Engineering",
  "College of Computer Science and Information Technology", 
  "College of Business Administration",
  "College of Medicine",
  "College of Science",
  "College of Arts and Humanities",
  "College of Education",
  "College of Law",
  "College of Pharmacy",
  "College of Dentistry"
];

export function EventRegistration({ event, onBack, onRegistrationSuccess }: EventRegistrationProps) {
  const [selectedCollege, setSelectedCollege] = useState<string>("");
  const [studentId, setStudentId] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCollege || !studentId) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (studentId.length !== 9) {
      toast.error("Student ID must be exactly 9 digits");
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success("Successfully registered for the event!");
      
      // Reset form and redirect to main page after a short delay
      setSelectedCollege("");
      setStudentId("");
      
      setTimeout(() => {
        toast.info("Redirecting to main page...");
        setTimeout(() => {
          onRegistrationSuccess();
        }, 800);
      }, 1500);
    }, 2000);
  };

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-4xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold text-[#0D2E57]">
            Event Registration
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Event Information */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle className="text-xl text-[#0D2E57]">
                Event Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-800 mb-4">
                  {event.title}
                </h2>
                <p className="text-gray-600 leading-relaxed">
                  {event.description}
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Calendar className="h-5 w-5 text-[#0D2E57]" />
                  <span className="text-gray-700">
                    {new Date(event.date).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long', 
                      day: 'numeric'
                    })}
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-[#0D2E57]" />
                  <span className="text-gray-700">
                    {event.location}
                  </span>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-blue-800 font-medium mb-1">
                      Important Note:
                    </p>
                    <p className="text-blue-700 text-sm leading-relaxed">
                      After registration, you will receive a confirmation email to your university email with all necessary details for attendance.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Registration Form */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-[#0D2E57]">
                Registration Form
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* College Selection */}
                <div className="space-y-2">
                  <Label htmlFor="college" className="block">
                    College Name *
                  </Label>
                  <Select value={selectedCollege} onValueChange={setSelectedCollege}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select your college" />
                    </SelectTrigger>
                    <SelectContent>
                      {colleges.map((college, index) => (
                        <SelectItem key={index} value={college}>
                          {college}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Student ID */}
                <div className="space-y-2">
                  <Label htmlFor="studentId" className="block">
                    Student ID *
                  </Label>
                  <Input
                    id="studentId"
                    type="text"
                    inputMode="numeric"
                    value={studentId}
                    onChange={(e) => {
                      // Only allow numbers
                      const value = e.target.value.replace(/[^0-9]/g, '');
                      setStudentId(value);
                    }}
                    onKeyPress={(e) => {
                      // Prevent non-numeric characters
                      if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'Tab') {
                        e.preventDefault();
                      }
                    }}
                    placeholder="Enter your student ID (numbers only)"
                    maxLength={9}
                  />
                  <p className="text-sm text-gray-500">
                    Must contain only numbers (9 digits)
                  </p>
                </div>

                {/* Additional Information */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600 leading-relaxed">
                    <strong>Additional Information:</strong><br />
                    • Registration is free for all students<br />
                    • Please arrive 15 minutes before the event starts<br />
                    • If unable to attend, please cancel your registration in advance
                  </p>
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit"
                  disabled={isSubmitting || !selectedCollege || !studentId}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg text-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Registering...</span>
                    </span>
                  ) : (
                    <span>Confirm Registration</span>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  By clicking "Confirm Registration", you agree to the terms and conditions for participation in university events
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}