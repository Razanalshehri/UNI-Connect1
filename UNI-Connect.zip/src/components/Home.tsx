import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Lightbulb, 
  MessageSquare,
  Bell,
  ChevronRight,
  UserCheck,
  BookOpen,
  Navigation
} from "lucide-react";

export function Home() {
  const upcomingEvents = [
    {
      id: 1,
      title: "Tech Innovation Summit",
      date: "2025-09-10",
      time: "2:00 PM",
      location: "Main Auditorium",
      attendees: 156,
      image: "https://images.unsplash.com/photo-1706016899218-ebe36844f70e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwYnVpbGRpbmd8ZW58MXx8fHwxNzU2NTYwNDA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 2,
      title: "Career Fair 2025",
      date: "2025-09-15",
      time: "10:00 AM",
      location: "Student Center",
      attendees: 340,
      image: "https://images.unsplash.com/photo-1706016899218-ebe36844f70e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwYnVpbGRpbmd8ZW58MXx8fHwxNzU2NTYwNDA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  const currentPoll = {
    question: "What type of campus events would you like to see more of?",
    options: [
      { id: 1, text: "Tech Workshops", votes: 45 },
      { id: 2, text: "Social Meetups", votes: 32 },
      { id: 3, text: "Career Events", votes: 67 },
      { id: 4, text: "Sports Activities", votes: 28 }
    ],
    totalVotes: 172
  };

  const officeHours = [
    {
      faculty: "Dr. Sarah Johnson",
      department: "Computer Science",
      office: "CS Building, Room 301",
      hours: "Mon, Wed 2-4 PM",
      available: true
    },
    {
      faculty: "Prof. Michael Chen",
      department: "Mathematics",
      office: "Math Building, Room 205",
      hours: "Tue, Thu 1-3 PM",
      available: false
    }
  ];

  const announcements = [
    {
      id: 1,
      title: "Library Extended Hours During Finals",
      category: "Academic",
      time: "2 hours ago",
      urgent: false
    },
    {
      id: 2,
      title: "Campus WiFi Maintenance Tonight",
      category: "Administrative",
      time: "4 hours ago",
      urgent: true
    }
  ];

  return (
    <div className="pb-20 space-y-6">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-6 rounded-b-2xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl text-white">Welcome to UNI Connect</h1>
            <p className="text-primary-foreground/80">Stay connected with your campus</p>
          </div>
          <Button variant="secondary" size="sm">
            <Bell className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-white">12</div>
              <div className="text-xs text-primary-foreground/80">Events This Week</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">3</div>
              <div className="text-xs text-primary-foreground/80">Active Polls</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">8</div>
              <div className="text-xs text-primary-foreground/80">New Ideas</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4">
        <h2 className="mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-4">
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <Navigation className="h-6 w-6 text-primary" />
            <span className="text-sm">Campus Map</span>
          </Button>
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <Lightbulb className="h-6 w-6 text-primary" />
            <span className="text-sm">Submit Idea</span>
          </Button>
        </div>
      </div>

      {/* Upcoming Events */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-4">
          <h2>Upcoming Events</h2>
          <Button variant="ghost" size="sm">
            View All <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
        
        <div className="space-y-4">
          {upcomingEvents.map((event) => (
            <Card key={event.id} className="overflow-hidden">
              <div className="flex">
                <ImageWithFallback
                  src={event.image}
                  alt={event.title}
                  className="w-20 h-20 object-cover"
                />
                <div className="flex-1 p-4">
                  <h3 className="font-medium mb-2">{event.title}</h3>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-3 w-3" />
                      <span>{event.date}</span>
                      <Clock className="h-3 w-3 ml-2" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-3 w-3" />
                      <span>{event.location}</span>
                      <Users className="h-3 w-3 ml-2" />
                      <span>{event.attendees} attending</span>
                    </div>
                  </div>
                  <Button size="sm" className="mt-2">
                    Register
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Current Poll */}
      <div className="px-4">
        <h2 className="mb-4">Campus Poll</h2>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{currentPoll.question}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {currentPoll.options.map((option) => {
              const percentage = Math.round((option.votes / currentPoll.totalVotes) * 100);
              return (
                <div key={option.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">{option.text}</span>
                    <span className="text-sm text-muted-foreground">{percentage}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
            <div className="text-xs text-muted-foreground text-center pt-2">
              {currentPoll.totalVotes} votes total
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Office Hours */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-4">
          <h2>Office Hours</h2>
          <Button variant="ghost" size="sm">
            View All <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
        
        <div className="space-y-3">
          {officeHours.map((faculty, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h3 className="font-medium">{faculty.faculty}</h3>
                    <p className="text-sm text-muted-foreground">{faculty.department}</p>
                  </div>
                  <Badge variant={faculty.available ? "default" : "secondary"}>
                    {faculty.available ? "Available" : "Busy"}
                  </Badge>
                </div>
                <div className="space-y-1 text-sm text-muted-foreground mb-3">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-3 w-3" />
                    <span>{faculty.office}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-3 w-3" />
                    <span>{faculty.hours}</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="flex-1" disabled={!faculty.available}>
                    <UserCheck className="h-3 w-3 mr-1" />
                    Book
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    Message
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Announcements */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-4">
          <h2>Latest Announcements</h2>
          <Button variant="ghost" size="sm">
            View All <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
        
        <div className="space-y-3">
          {announcements.map((announcement) => (
            <Card key={announcement.id} className={announcement.urgent ? "border-destructive/50 bg-destructive/5" : ""}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <Badge variant={announcement.urgent ? "destructive" : "secondary"} className="text-xs">
                        {announcement.category}
                      </Badge>
                      {announcement.urgent && (
                        <Badge variant="destructive" className="text-xs">
                          Urgent
                        </Badge>
                      )}
                    </div>
                    <h3 className="font-medium">{announcement.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{announcement.time}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Idea Submission */}
      <div className="px-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Lightbulb className="h-5 w-5 text-primary" />
              <span>Got an Idea?</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Share your ideas for campus events, improvements, or activities. Your voice matters!
            </p>
            <Button className="w-full">
              Submit Your Idea
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}