import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { ArrowLeft, Clock, User, MapPin, Search, Calendar, Mail, Phone } from "lucide-react";

interface OfficeHoursProps {
  onBack: () => void;
}

interface FacultyMember {
  id: string;
  name: string;
  college: string;
  title: string;
  email: string;
  officeHours: {
    day: string;
    time: string;
    office: string;
  }[];
}

const facultyData: FacultyMember[] = [
  // College of Engineering
  {
    id: "1",
    name: "Dr. Ahmed Mohammed Ali",
    college: "College of Engineering",
    title: "Professor of Civil Engineering",
    email: "aali@kau.edu.sa",
    officeHours: [
      { day: "Sunday", time: "10:00 AM - 12:00 PM", office: "Office 201 - Civil Engineering Building" },
      { day: "Tuesday", time: "2:00 PM - 4:00 PM", office: "Office 201 - Civil Engineering Building" },
      { day: "Thursday", time: "9:00 AM - 11:00 AM", office: "Office 201 - Civil Engineering Building" }
    ]
  },
  {
    id: "2",
    name: "Dr. Fatima Saad Al-Najjar",
    college: "College of Engineering",
    title: "Assistant Professor of Electrical Engineering",
    email: "fnajjar@kau.edu.sa",
    officeHours: [
      { day: "Monday", time: "11:00 AM - 1:00 PM", office: "Office A15 - Electrical Engineering Building" },
      { day: "Wednesday", time: "3:00 PM - 5:00 PM", office: "Office A15 - Electrical Engineering Building" }
    ]
  },
  {
    id: "3",
    name: "Dr. Abdulrahman Khalid Al-Sayed",
    college: "College of Engineering",
    title: "Professor of Mechanical Engineering",
    email: "asayed@kau.edu.sa",
    officeHours: [
      { day: "Sunday", time: "1:00 PM - 3:00 PM", office: "Office M102 - Mechanical Engineering Building" },
      { day: "Tuesday", time: "10:00 AM - 12:00 PM", office: "Office M102 - Mechanical Engineering Building" }
    ]
  },

  // College of Computer Science and Information Technology
  {
    id: "4",
    name: "Dr. Sarah Ahmed Al-Qahtani",
    college: "College of Computer Science and Information Technology",
    title: "Professor of Computer Science",
    email: "sqahtani@kau.edu.sa",
    officeHours: [
      { day: "Monday", time: "9:00 AM - 11:00 AM", office: "Office CS201 - Computer Science Building" },
      { day: "Wednesday", time: "2:00 PM - 4:00 PM", office: "Office CS201 - Computer Science Building" },
      { day: "Thursday", time: "10:00 AM - 12:00 PM", office: "Office CS201 - Computer Science Building" }
    ]
  },
  {
    id: "5",
    name: "Dr. Mohammed Abdullah Al-Shahri",
    college: "College of Computer Science and Information Technology",
    title: "Associate Professor of Information Technology",
    email: "mshahri@kau.edu.sa",
    officeHours: [
      { day: "Sunday", time: "11:00 AM - 1:00 PM", office: "Office IT105 - Information Technology Building" },
      { day: "Tuesday", time: "3:00 PM - 5:00 PM", office: "Office IT105 - Information Technology Building" }
    ]
  },

  // College of Business Administration
  {
    id: "6",
    name: "Dr. Nora Salim Al-Ghamdi",
    college: "College of Business Administration",
    title: "Professor of Business Administration",
    email: "nghamdi@kau.edu.sa",
    officeHours: [
      { day: "Monday", time: "10:00 AM - 12:00 PM", office: "Office BA201 - Business Administration Building" },
      { day: "Wednesday", time: "1:00 PM - 3:00 PM", office: "Office BA201 - Business Administration Building" }
    ]
  },
  {
    id: "7",
    name: "Dr. Youssef Mohammed Al-Zahrani",
    college: "College of Business Administration",
    title: "Assistant Professor of Accounting",
    email: "yzahrani@kau.edu.sa",
    officeHours: [
      { day: "Sunday", time: "2:00 PM - 4:00 PM", office: "Office BA105 - Business Administration Building" },
      { day: "Tuesday", time: "9:00 AM - 11:00 AM", office: "Office BA105 - Business Administration Building" },
      { day: "Thursday", time: "3:00 PM - 5:00 PM", office: "Office BA105 - Business Administration Building" }
    ]
  },

  // College of Medicine
  {
    id: "8",
    name: "Dr. Layla Hassan Al-Bashri",
    college: "College of Medicine",
    title: "Professor of Internal Medicine",
    email: "lbashri@kau.edu.sa",
    officeHours: [
      { day: "Monday", time: "8:00 AM - 10:00 AM", office: "Office MED301 - Basic Medicine Building" },
      { day: "Wednesday", time: "4:00 PM - 6:00 PM", office: "Office MED301 - Basic Medicine Building" }
    ]
  },
  {
    id: "9",
    name: "Dr. Khalid Ahmed Al-Malki",
    college: "College of Medicine",
    title: "Associate Professor of Surgery",
    email: "kmaliki@kau.edu.sa",
    officeHours: [
      { day: "Sunday", time: "3:00 PM - 5:00 PM", office: "Office SUR201 - University Hospital" },
      { day: "Tuesday", time: "1:00 PM - 3:00 PM", office: "Office SUR201 - University Hospital" }
    ]
  },

  // College of Science
  {
    id: "10",
    name: "Dr. Maryam Ali Al-Harbi",
    college: "College of Science",
    title: "Professor of Physics",
    email: "mharbi@kau.edu.sa",
    officeHours: [
      { day: "Monday", time: "9:00 AM - 11:00 AM", office: "Office PHY201 - Science Building" },
      { day: "Thursday", time: "2:00 PM - 4:00 PM", office: "Office PHY201 - Science Building" }
    ]
  }
];

const colleges = [
  "College of Engineering",
  "College of Computer Science and Information Technology", 
  "College of Business Administration",
  "College of Medicine",
  "College of Science",
  "College of Arts and Humanities",
  "College of Education",
  "College of Law",
  "College of Pharmacy",
  "College of Dentistry"
];

export function OfficeHours({ onBack }: OfficeHoursProps) {
  const [selectedCollege, setSelectedCollege] = useState<string>("");
  const [selectedFaculty, setSelectedFaculty] = useState<string>("");
  const [searchResults, setSearchResults] = useState<FacultyMember | null>(null);
  const [showResults, setShowResults] = useState(false);

  const getFacultyByCollege = (college: string) => {
    return facultyData.filter(faculty => faculty.college === college);
  };

  const facultyMembers = selectedCollege ? getFacultyByCollege(selectedCollege) : [];

  const handleSearch = () => {
    if (selectedFaculty) {
      const faculty = facultyData.find(f => f.id === selectedFaculty);
      setSearchResults(faculty || null);
      setShowResults(true);
    }
  };

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-6xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold text-[#0D2E57] flex items-center space-x-3">
            <Clock className="h-8 w-8" />
            <span>Office Hours</span>
          </h1>
        </div>

        {/* Search Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl text-[#0D2E57] flex items-center space-x-2">
              <Search className="h-6 w-6" />
              <span>Search Faculty Member</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* College Selection */}
              <div className="space-y-2">
                <Label className="block">
                  College Name *
                </Label>
                <Select 
                  value={selectedCollege} 
                  onValueChange={(value) => {
                    setSelectedCollege(value);
                    setSelectedFaculty("");
                    setShowResults(false);
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose College" />
                  </SelectTrigger>
                  <SelectContent>
                    {colleges.map((college, index) => (
                      <SelectItem key={index} value={college}>
                        {college}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Faculty Selection */}
              <div className="space-y-2">
                <Label className="block">
                  Faculty Member Name *
                </Label>
                <Select 
                  value={selectedFaculty} 
                  onValueChange={setSelectedFaculty}
                  disabled={!selectedCollege}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose Faculty Member" />
                  </SelectTrigger>
                  <SelectContent>
                    {facultyMembers.map((faculty) => (
                      <SelectItem key={faculty.id} value={faculty.id}>
                        {faculty.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Search Button */}
              <div className="space-y-2">
                <Label className="block opacity-0">
                  Search
                </Label>
                <Button 
                  onClick={handleSearch}
                  disabled={!selectedFaculty}
                  className="w-full bg-[#0D2E57] hover:bg-[#0D2E57]/90 text-white py-2 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <span className="flex items-center justify-center space-x-2">
                    <Search className="h-4 w-4" />
                    <span>Search</span>
                  </span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Search Results */}
        {showResults && searchResults && (
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-[#0D2E57] flex items-center space-x-2">
                <User className="h-6 w-6" />
                <span>Office Hours: {searchResults.name}</span>
              </CardTitle>
              <div className="space-y-2 mt-2">
                <div className="flex items-center space-x-2">
                  <span className="text-gray-600">{searchResults.college}</span>
                  <span className="text-gray-400">•</span>
                  <span className="text-gray-600">{searchResults.title}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <a 
                    href={`mailto:${searchResults.email}`}
                    className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 text-sm"
                  >
                    <Mail className="h-4 w-4" />
                    <span>{searchResults.email}</span>
                  </a>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {searchResults.officeHours.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>Day</span>
                          </div>
                        </TableHead>
                        <TableHead>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>Office Hours</span>
                          </div>
                        </TableHead>
                        <TableHead>
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-4 w-4" />
                            <span>Office Number</span>
                          </div>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {searchResults.officeHours.map((schedule, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">
                            {schedule.day}
                          </TableCell>
                          <TableCell>
                            {schedule.time}
                          </TableCell>
                          <TableCell>
                            {schedule.office}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">
                    No office hours scheduled for this faculty member currently
                  </p>
                </div>
              )}

              {/* Contact and Additional Information */}
              <div className="mt-6 space-y-4">
                {/* Contact Section */}
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="space-y-3">
                    <h4 className="font-medium text-green-800 flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <span>Contact Methods</span>
                    </h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-3 bg-white rounded border">
                        <a 
                          href={`mailto:${searchResults.email}?subject=Office Hours Inquiry&body=Dear Dr. ${searchResults.name},%0A%0AI would like to schedule an appointment or inquire about:%0A%0A%0AThank you`}
                          className="flex items-center space-x-2 text-blue-600 hover:text-blue-800"
                        >
                          <Mail className="h-4 w-4" />
                          <span>Send Email</span>
                        </a>
                        <span className="text-xs text-gray-500">{searchResults.email}</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-white rounded border">
                        <div className="flex items-center space-x-2 text-green-600">
                          <Phone className="h-4 w-4" />
                          <span>Office Phone</span>
                        </div>
                        <span className="text-xs text-gray-500">012-6400000 Ext. 1234</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Additional Information */}
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="space-y-2">
                    <h4 className="font-medium text-blue-800">
                      Important Notes:
                    </h4>
                    <ul className="space-y-1 text-sm text-blue-700">
                      <li>• Please confirm appointment before visiting</li>
                      <li>• It's preferred to schedule in advance via university email</li>
                      <li>• Office hours may change during exam periods</li>
                      <li>• If faculty member is unavailable, please try another time</li>
                      <li>• Use university email for official communication</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Instructions when no search is made */}
        {!showResults && (
          <Card>
            <CardContent className="py-12">
              <div className="text-center">
                <Clock className="h-16 w-16 text-gray-400 mx-auto mb-6" />
                <h3 className="text-xl font-medium text-gray-700 mb-4">
                  Search for Office Hours
                </h3>
                <p className="text-gray-500 max-w-md mx-auto leading-relaxed">
                  Choose a college and faculty member to view their office hours and contact information
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <Card>
            <CardContent className="p-6 text-center">
              <User className="h-8 w-8 text-[#0D2E57] mx-auto mb-3" />
              <div>
                <p className="text-2xl font-bold text-gray-800">{facultyData.length}</p>
                <p className="text-gray-600">Faculty Members</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Calendar className="h-8 w-8 text-[#0D2E57] mx-auto mb-3" />
              <div>
                <p className="text-2xl font-bold text-gray-800">5</p>
                <p className="text-gray-600">Days per Week</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <MapPin className="h-8 w-8 text-[#0D2E57] mx-auto mb-3" />
              <div>
                <p className="text-2xl font-bold text-gray-800">{colleges.length}</p>
                <p className="text-gray-600">Available Colleges</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}