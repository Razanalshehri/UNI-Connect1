import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Switch } from "./ui/switch";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "./ui/dialog";
import {
  ArrowRight,
  BarChart3,
  Users,
  Calendar,
  Vote,
  FileText,
  Settings,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Eye,
  Edit3,
  Trash2,
  Plus,
  Download,
  Upload,
  Search,
  Filter,
  Shield,
  Bell,
  Database,
  Activity,
  PieChart,
  UserCheck,
  MessageSquare,
  Star,
  Heart,
  Target,
  Megaphone,
  Save,
  X,
  Send,
  ThumbsUp,
  ThumbsDown,
  ChevronDown,
  ChevronUp,
  Mail,
  Phone,
  User,
  GraduationCap,
  MapPin,
  Image
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface AdminPanelProps {
  onBack: () => void;
}

// Mock data for admin statistics
const adminStats = {
  totalUsers: 2847,
  totalEvents: 156,
  totalVotes: 8432,
  totalRequests: 293,
  activeUsers: 1205,
  pendingRequests: 47,
  completedEvents: 89,
  averageRating: 4.6
};

const recentActivities = [
  { id: 1, type: "event", title: "تم إنشاء فعالية جديدة: معرض التقنية", time: "منذ ساعة", status: "pending" },
  { id: 2, type: "vote", title: "اكتمال التصويت على مقترح المكتبة الرقمية", time: "منذ 3 ساعات", status: "completed" },
  { id: 3, type: "request", title: "طلب جديد: تطوير تطبيق الجوال", time: "منذ 5 ساعات", status: "pending" },
  { id: 4, type: "user", title: "انضمام 15 طالب جديد للمنصة", time: "اليوم", status: "completed" },
  { id: 5, type: "news", title: "تم نشر خبر: بدء التسجيل للفصل الصيفي", time: "أمس", status: "completed" }
];

const mockEvents = [
  { 
    id: 1, 
    title: "معرض الابتكار التقني", 
    description: "معرض سنوي لعرض مشاريع الطلاب التقنية والابتكارية", 
    date: "2024-03-15", 
    time: "09:00 ص", 
    location: "القاعة الرئيسية", 
    status: "active", 
    participants: 156, 
    maxParticipants: 200,
    category: "تقنية"
  },
  { 
    id: 2, 
    title: "مؤتمر ريادة الأعمال", 
    description: "مؤتمر يضم نخبة من رواد الأعمال والمستثمرين", 
    date: "2024-03-20", 
    time: "10:00 ص", 
    location: "مركز المؤتمرات", 
    status: "pending", 
    participants: 89, 
    maxParticipants: 150,
    category: "أعمال"
  },
  { 
    id: 3, 
    title: "ورشة الذكاء الاصطناعي", 
    description: "ورشة تدريبية في أساسيات الذكاء الاصطناعي والتعلم الآلي", 
    date: "2024-03-25", 
    time: "02:00 م", 
    location: "مختبر الحاسب", 
    status: "completed", 
    participants: 234, 
    maxParticipants: 250,
    category: "تدريب"
  }
];

const mockRequests = [
  { 
    id: 1, 
    title: "طلب إقامة معرض للكتب", 
    description: "أقترح إقامة معرض سنوي للكتب في مكتبة الجامعة لتشجيع القراءة وتبادل الكتب بين الطلاب. يمكن أن يشمل المعرض كتب أكاديمية وثقافية ومسابقات أدبية.",
    student: "أحمد محمد علي", 
    email: "ahmed.mohammed@kau.edu.sa",
    studentId: "123456789",
    college: "كلية الآداب والعلوم الإنسانية",
    phone: "0501234567",
    status: "pending", 
    date: "2024-03-10",
    comments: [],
    voteStatus: "none" // none, voting, completed
  },
  { 
    id: 2, 
    title: "اقتراح تطوير مساحة دراسية", 
    description: "أقترح تطوير مساحات دراسية هادئة ومريحة في المكتبة الرئيسية مع توفير مقاعد مريحة وإضاءة جيدة ومناطق للدراسة الجماعية والفردية.",
    student: "سارة أحمد الزهراني", 
    email: "sarah.ahmed@kau.edu.sa",
    studentId: "987654321",
    college: "كلية الهندسة",
    phone: "0507654321",
    status: "approved", 
    date: "2024-03-08",
    comments: [
      { id: 1, author: "د. محمد الأحمد", message: "اقتراح ممتاز، سيتم التنفيذ في الفصل القادم", date: "2024-03-09" }
    ],
    voteStatus: "none"
  },
  { 
    id: 3, 
    title: "طلب ورشة تدريبية في البرمجة", 
    description: "أطلب تنظيم ورشة تدريبية في البرمجة باستخدام Python وJavaScript للطلاب المبتدئين مع شهادات معتمدة.",
    student: "محمد علي القرني", 
    email: "mohammed.ali@kau.edu.sa",
    studentId: "456789123",
    college: "كلية علوم الحاسب وتقنية المعلومات",
    phone: "0509876543",
    status: "rejected", 
    date: "2024-03-05",
    comments: [
      { id: 1, author: "د. فاطمة السعد", message: "يتوفر بالفعل برنامج تدريبي مشابه في القسم", date: "2024-03-06" }
    ],
    voteStatus: "none"
  }
];

const mockAnnouncements = [
  {
    id: 1,
    title: "جامعة الملك عبد العزيز تحتل المرتبة الأولى محلياً في التصنيف العالمي",
    content: "حققت جامعة الملك عبد العزيز إنجازاً تاريخياً بحصولها على المرتبة الأولى محلياً في التصنيف العالمي للجامعات...",
    category: "إنجازات",
    status: "published",
    publishDate: "2024-03-12",
    image: "https://images.unsplash.com/photo-1563290331-f295b4fb2fd3",
    views: 2847,
    isHot: true
  },
  {
    id: 2,
    title: "حفل تخريج الدفعة 45 من طلاب وطالبات الجامعة",
    content: "تحتفل الجامعة بتخريج أكثر من 8000 طالب وطالبة من مختلف الكليات والتخصصات...",
    category: "فعاليات",
    status: "draft",
    publishDate: "2024-03-15",
    image: "https://images.unsplash.com/photo-1738949538943-e54722a44ffc",
    views: 0,
    isHot: false
  }
];

export function AdminPanel({ onBack }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<any>(null);
  const [requestModalOpen, setRequestModalOpen] = useState(false);
  const [eventModalOpen, setEventModalOpen] = useState(false);
  const [announcementModalOpen, setAnnouncementModalOpen] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [eventForm, setEventForm] = useState({
    title: "",
    description: "",
    date: "",
    time: "",
    location: "",
    maxParticipants: "",
    category: ""
  });
  const [announcementForm, setAnnouncementForm] = useState({
    title: "",
    content: "",
    category: "",
    image: "",
    isHot: false
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'approved':
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'rejected':
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    const statusMap: { [key: string]: string } = {
      'active': 'نشط',
      'pending': 'قيد المراجعة',
      'completed': 'مكتمل',
      'approved': 'موافق عليه',
      'rejected': 'مرفوض',
      'cancelled': 'ملغي',
      'published': 'منشور',
      'draft': 'مسودة',
      'voting': 'تحت التصويت'
    };
    return statusMap[status] || status;
  };

  const handleViewRequest = (request: any) => {
    setSelectedRequest(request);
    setRequestModalOpen(true);
  };

  const handleEditEvent = (event: any) => {
    setSelectedEvent(event);
    setEventForm({
      title: event.title,
      description: event.description,
      date: event.date,
      time: event.time,
      location: event.location,
      maxParticipants: event.maxParticipants.toString(),
      category: event.category
    });
    setEventModalOpen(true);
  };

  const handleAddComment = () => {
    if (!commentText.trim()) return;
    
    const newComment = {
      id: Date.now(),
      author: "المشرف العام",
      message: commentText,
      date: new Date().toLocaleDateString('ar-SA')
    };
    
    // In real app, update backend
    toast.success("تم إضافة التعليق بنجاح");
    setCommentText("");
  };

  const handleMoveToVoting = (requestId: number) => {
    toast.success("تم نقل الطلب إلى منطقة التصويت");
    setRequestModalOpen(false);
  };

  const handleSaveEvent = () => {
    // In real app, save to backend
    toast.success("تم حفظ تعديلات الفعالية بنجاح");
    setEventModalOpen(false);
  };

  const handleSaveAnnouncement = () => {
    // In real app, save to backend
    toast.success("تم حفظ الإعلان بنجاح");
    setAnnouncementModalOpen(false);
    setAnnouncementForm({
      title: "",
      content: "",
      category: "",
      image: "",
      isHot: false
    });
  };

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8" dir="rtl">
          <div className="flex items-center">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center"
            >
              <ArrowRight className="h-4 w-4 ml-2" />
              <span className="arabic-text">رجوع</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold arabic-text text-[#0D2E57] flex items-center">
            <span>لوحة التحكم الإدارية</span>
            <Shield className="h-8 w-8 mr-4" />
          </h1>
        </div>

        {/* Admin Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-7 mb-6" dir="rtl">
            <TabsTrigger value="dashboard" className="arabic-text">
              <BarChart3 className="h-4 w-4 ml-2" />
              الرئيسية
            </TabsTrigger>
            <TabsTrigger value="events" className="arabic-text">
              <Calendar className="h-4 w-4 ml-2" />
              الفعاليات
            </TabsTrigger>
            <TabsTrigger value="requests" className="arabic-text">
              <FileText className="h-4 w-4 ml-2" />
              الطلبات
            </TabsTrigger>
            <TabsTrigger value="announcements" className="arabic-text">
              <Megaphone className="h-4 w-4 ml-2" />
              الإعلانات
            </TabsTrigger>
            <TabsTrigger value="users" className="arabic-text">
              <Users className="h-4 w-4 ml-2" />
              المستخدمين
            </TabsTrigger>
            <TabsTrigger value="votes" className="arabic-text">
              <Vote className="h-4 w-4 ml-2" />
              التصويتات
            </TabsTrigger>
            <TabsTrigger value="settings" className="arabic-text">
              <Settings className="h-4 w-4 ml-2" />
              الإعدادات
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard">
            <div className="space-y-6">
              {/* Statistics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                  <CardContent className="p-6" dir="rtl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-600 arabic-text text-sm">إجمالي المستخدمين</p>
                        <p className="text-2xl font-bold text-blue-800">{adminStats.totalUsers.toLocaleString()}</p>
                      </div>
                      <div className="p-3 bg-blue-200 rounded-full">
                        <Users className="h-6 w-6 text-blue-600" />
                      </div>
                    </div>
                    <div className="flex items-center mt-3">
                      <TrendingUp className="h-4 w-4 text-green-600 ml-2" />
                      <span className="text-green-600 text-sm arabic-text">زيادة 12% هذا الشهر</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                  <CardContent className="p-6" dir="rtl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-600 arabic-text text-sm">إجمالي الفعاليات</p>
                        <p className="text-2xl font-bold text-green-800">{adminStats.totalEvents}</p>
                      </div>
                      <div className="p-3 bg-green-200 rounded-full">
                        <Calendar className="h-6 w-6 text-green-600" />
                      </div>
                    </div>
                    <div className="flex items-center mt-3">
                      <Target className="h-4 w-4 text-green-600 ml-2" />
                      <span className="text-green-600 text-sm arabic-text">{adminStats.completedEvents} فعالية مكتملة</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                  <CardContent className="p-6" dir="rtl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-600 arabic-text text-sm">إجمالي الأصوات</p>
                        <p className="text-2xl font-bold text-purple-800">{adminStats.totalVotes.toLocaleString()}</p>
                      </div>
                      <div className="p-3 bg-purple-200 rounded-full">
                        <Vote className="h-6 w-6 text-purple-600" />
                      </div>
                    </div>
                    <div className="flex items-center mt-3">
                      <Activity className="h-4 w-4 text-purple-600 ml-2" />
                      <span className="text-purple-600 text-sm arabic-text">معدل المشاركة 68%</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
                  <CardContent className="p-6" dir="rtl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-orange-600 arabic-text text-sm">الطلبات المعلقة</p>
                        <p className="text-2xl font-bold text-orange-800">{adminStats.pendingRequests}</p>
                      </div>
                      <div className="p-3 bg-orange-200 rounded-full">
                        <Clock className="h-6 w-6 text-orange-600" />
                      </div>
                    </div>
                    <div className="flex items-center mt-3">
                      <AlertCircle className="h-4 w-4 text-orange-600 ml-2" />
                      <span className="text-orange-600 text-sm arabic-text">تحتاج مراجعة</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Charts and Recent Activities */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* User Activity Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="arabic-text text-right text-xl text-[#0D2E57] flex items-center justify-end">
                      <span>نشاط المستخدمين</span>
                      <PieChart className="h-6 w-6 mr-3" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between" dir="rtl">
                        <span className="text-sm arabic-text">المستخدمين النشطين</span>
                        <span className="font-medium">{adminStats.activeUsers}</span>
                      </div>
                      <Progress value={72} className="h-2" />
                      
                      <div className="flex items-center justify-between" dir="rtl">
                        <span className="text-sm arabic-text">معدل التفاعل</span>
                        <span className="font-medium">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                      
                      <div className="flex items-center justify-between" dir="rtl">
                        <span className="text-sm arabic-text">الرضا العام</span>
                        <div className="flex items-center">
                          <span className="font-medium ml-1">{adminStats.averageRating}</span>
                          <Star className="h-4 w-4 text-yellow-500" />
                        </div>
                      </div>
                      <Progress value={92} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Activities */}
                <Card>
                  <CardHeader>
                    <CardTitle className="arabic-text text-right text-xl text-[#0D2E57] flex items-center justify-end">
                      <span>الأنشطة الحديثة</span>
                      <Activity className="h-6 w-6 mr-3" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivities.map((activity) => (
                        <div key={activity.id} className="flex items-start justify-between p-3 bg-gray-50 rounded-lg" dir="rtl">
                          <div className="flex-1">
                            <p className="text-sm font-medium arabic-text text-right">{activity.title}</p>
                            <p className="text-xs text-gray-500 arabic-text text-right">{activity.time}</p>
                          </div>
                          <Badge className={`text-xs ${getStatusColor(activity.status)}`}>
                            {getStatusText(activity.status)}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Events Management Tab */}
          <TabsContent value="events">
            <div className="space-y-6">
              <div className="flex items-center justify-between" dir="rtl">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <Button className="bg-[#0D2E57] hover:bg-[#0D2E57]/90 text-white">
                    <Plus className="h-4 w-4 ml-2" />
                    <span className="arabic-text">إضافة فعالية جديدة</span>
                  </Button>
                  <Button variant="outline">
                    <Download className="h-4 w-4 ml-2" />
                    <span className="arabic-text">تصدير البيانات</span>
                  </Button>
                </div>
                <div className="flex items-center space-x-4 space-x-reverse">
                  <Input 
                    placeholder="البحث في الفعاليات..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-64 text-right arabic-text"
                  />
                  <Button variant="outline" size="sm">
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="arabic-text text-right text-xl text-[#0D2E57]">
                    إدارة الفعاليات
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockEvents.map((event) => (
                      <div key={event.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg" dir="rtl">
                        <div className="flex-1">
                          <h4 className="font-medium arabic-text text-right">{event.title}</h4>
                          <p className="text-sm text-gray-600 arabic-text text-right">
                            التاريخ: {new Date(event.date).toLocaleDateString('ar-SA')} - المشاركين: {event.participants}/{event.maxParticipants}
                          </p>
                          <p className="text-xs text-gray-500 arabic-text text-right">
                            {event.location} - {event.time}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Badge className={getStatusColor(event.status)}>
                            {getStatusText(event.status)}
                          </Badge>
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleEditEvent(event)}
                          >
                            <Edit3 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Requests Management Tab */}
          <TabsContent value="requests">
            <div className="space-y-6">
              <div className="flex items-center justify-between" dir="rtl">
                <h2 className="text-2xl font-bold arabic-text text-[#0D2E57]">إدارة الطلبات</h2>
                <div className="flex items-center space-x-4 space-x-reverse">
                  <Select>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="تصفية حسب الحالة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الطلبات</SelectItem>
                      <SelectItem value="pending">قيد المراجعة</SelectItem>
                      <SelectItem value="approved">موافق عليها</SelectItem>
                      <SelectItem value="rejected">مرفوضة</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 ml-2" />
                    <span className="arabic-text">تصفية</span>
                  </Button>
                </div>
              </div>

              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {mockRequests.map((request) => (
                      <div key={request.id} className="border rounded-lg p-4" dir="rtl">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold arabic-text text-right">{request.title}</h4>
                            <div className="flex items-center mt-2 space-x-4 space-x-reverse">
                              <div className="flex items-center">
                                <User className="h-4 w-4 text-gray-500 ml-1" />
                                <span className="text-sm text-gray-600 arabic-text">{request.student}</span>
                              </div>
                              <div className="flex items-center">
                                <GraduationCap className="h-4 w-4 text-gray-500 ml-1" />
                                <span className="text-sm text-gray-600 arabic-text">{request.studentId}</span>
                              </div>
                              <div className="flex items-center">
                                <Clock className="h-4 w-4 text-gray-500 ml-1" />
                                <span className="text-sm text-gray-600 arabic-text">{new Date(request.date).toLocaleDateString('ar-SA')}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <Badge className={getStatusColor(request.status)}>
                              {getStatusText(request.status)}
                            </Badge>
                            {request.voteStatus === 'voting' && (
                              <Badge className="bg-purple-100 text-purple-800">تحت التصويت</Badge>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 space-x-reverse mt-4">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleViewRequest(request)}
                          >
                            <Eye className="h-4 w-4 ml-1" />
                            عرض التفاصيل
                          </Button>
                          
                          {request.status === 'pending' && (
                            <>
                              <Button 
                                size="sm" 
                                className="bg-green-600 hover:bg-green-700"
                                onClick={() => toast.success("تم الموافقة على الطلب")}
                              >
                                <CheckCircle className="h-4 w-4 ml-1" />
                                موافقة
                              </Button>
                              <Button 
                                size="sm" 
                                variant="destructive"
                                onClick={() => toast.error("تم رفض الطلب")}
                              >
                                <AlertCircle className="h-4 w-4 ml-1" />
                                رفض
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="bg-purple-50 hover:bg-purple-100"
                                onClick={() => handleMoveToVoting(request.id)}
                              >
                                <Vote className="h-4 w-4 ml-1" />
                                نقل للتصويت
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Management Tab */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle className="arabic-text text-right text-xl text-[#0D2E57] flex items-center justify-end">
                  <span>إدارة المستخدمين</span>
                  <UserCheck className="h-6 w-6 mr-3" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Database className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium arabic-text text-gray-900 mb-2">
                    قريباً: إدارة المستخدمين
                  </h3>
                  <p className="text-gray-600 arabic-text">
                    ستتوفر هذه الميزة قريباً لإدارة حسابات المستخدمين والصلاحيات
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Announcements Management Tab */}
          <TabsContent value="announcements">
            <div className="space-y-6">
              <div className="flex items-center justify-between" dir="rtl">
                <h2 className="text-2xl font-bold arabic-text text-[#0D2E57]">إدارة الإعلانات والأخبار</h2>
                <Button 
                  className="bg-[#0D2E57] hover:bg-[#0D2E57]/90 text-white"
                  onClick={() => setAnnouncementModalOpen(true)}
                >
                  <Plus className="h-4 w-4 ml-2" />
                  <span className="arabic-text">إضافة إعلان جديد</span>
                </Button>
              </div>

              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {mockAnnouncements.map((announcement) => (
                      <div key={announcement.id} className="border rounded-lg p-4" dir="rtl">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 space-x-reverse mb-2">
                              <h4 className="font-semibold arabic-text text-right">{announcement.title}</h4>
                              {announcement.isHot && (
                                <Badge className="bg-red-100 text-red-800">عاجل</Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-600 arabic-text text-right mb-2">
                              {announcement.content.substring(0, 150)}...
                            </p>
                            <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-500">
                              <span className="arabic-text">{announcement.category}</span>
                              <span>{new Date(announcement.publishDate).toLocaleDateString('ar-SA')}</span>
                              <div className="flex items-center">
                                <Eye className="h-4 w-4 ml-1" />
                                <span>{announcement.views} مشاهدة</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <Badge className={getStatusColor(announcement.status)}>
                              {getStatusText(announcement.status)}
                            </Badge>
                            <Button variant="ghost" size="sm">
                              <Edit3 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Votes Management Tab */}
          <TabsContent value="votes">
            <Card>
              <CardHeader>
                <CardTitle className="arabic-text text-right text-xl text-[#0D2E57] flex items-center justify-end">
                  <span>إدارة التصويتات</span>
                  <Vote className="h-6 w-6 mr-3" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Vote className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium arabic-text text-gray-900 mb-2">
                    قريباً: إدارة التصويتات
                  </h3>
                  <p className="text-gray-600 arabic-text">
                    ستتوفر هذه الميزة قريباً لإدارة الاستطلاعات والتصويتات
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="arabic-text text-right text-xl text-[#0D2E57] flex items-center justify-end">
                    <span>إعدادات النظام</span>
                    <Settings className="h-6 w-6 mr-3" />
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6" dir="rtl">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="arabic-text text-right">تفعيل الإشعارات</Label>
                        <p className="text-sm text-gray-600 arabic-text">إرسال إشعارات للمستخدمين</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="arabic-text text-right">الموافقة التلقائية على الطلبات</Label>
                        <p className="text-sm text-gray-600 arabic-text">الموافقة تلقائياً على طلبات معينة</p>
                      </div>
                      <Switch />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="arabic-text text-right">عرض الإحصائيات العامة</Label>
                        <p className="text-sm text-gray-600 arabic-text">إظهار الإحصائيات في الصفحة الرئيسية</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <div className="border-t pt-6">
                    <h4 className="text-lg font-medium arabic-text text-right mb-4">إعدادات النسخ الاحتياطي</h4>
                    <div className="space-y-4">
                      <Button className="w-full" variant="outline">
                        <Upload className="h-4 w-4 ml-2" />
                        <span className="arabic-text">إنشاء نسخة احتياطية</span>
                      </Button>
                      <Button className="w-full" variant="outline">
                        <Download className="h-4 w-4 ml-2" />
                        <span className="arabic-text">تنزيل البيانات</span>
                      </Button>
                    </div>
                  </div>

                  <div className="border-t pt-6">
                    <h4 className="text-lg font-medium arabic-text text-right mb-4">معلومات النظام</h4>
                    <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">إصدار النظام:</span>
                        <span className="text-sm font-medium">1.0.0</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">آخر تحديث:</span>
                        <span className="text-sm font-medium">2024-03-12</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">حالة النظام:</span>
                        <Badge className="bg-green-100 text-green-800">متاح</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Request Details Modal */}
        <Dialog open={requestModalOpen} onOpenChange={setRequestModalOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="arabic-text text-right text-xl text-[#0D2E57]">
                تفاصيل الطلب
              </DialogTitle>
              <DialogDescription className="arabic-text text-right">
                عرض تفاصيل شاملة للطلب المقدم من الطالب مع إمكانية إضافة التعليقات واتخاذ الإجراءات المناسبة
              </DialogDescription>
            </DialogHeader>
            {selectedRequest && (
              <div className="space-y-6" dir="rtl">
                {/* Student Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="arabic-text text-right text-lg">بيانات الطالب</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center">
                        <User className="h-5 w-5 text-gray-500 ml-3" />
                        <div>
                          <Label className="text-sm text-gray-600 arabic-text">اسم الطالب</Label>
                          <p className="font-medium arabic-text">{selectedRequest.student}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <GraduationCap className="h-5 w-5 text-gray-500 ml-3" />
                        <div>
                          <Label className="text-sm text-gray-600 arabic-text">الرقم الجامعي</Label>
                          <p className="font-medium">{selectedRequest.studentId}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Mail className="h-5 w-5 text-gray-500 ml-3" />
                        <div>
                          <Label className="text-sm text-gray-600 arabic-text">البريد الإلكتروني</Label>
                          <p className="font-medium">{selectedRequest.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Phone className="h-5 w-5 text-gray-500 ml-3" />
                        <div>
                          <Label className="text-sm text-gray-600 arabic-text">رقم الهاتف</Label>
                          <p className="font-medium">{selectedRequest.phone}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-5 w-5 text-gray-500 ml-3" />
                      <div>
                        <Label className="text-sm text-gray-600 arabic-text">الكلية</Label>
                        <p className="font-medium arabic-text">{selectedRequest.college}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Request Details */}
                <Card>
                  <CardHeader>
                    <CardTitle className="arabic-text text-right text-lg">تفاصيل الطلب</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-sm text-gray-600 arabic-text">عنوان الطلب</Label>
                      <p className="font-medium arabic-text text-right">{selectedRequest.title}</p>
                    </div>
                    <div>
                      <Label className="text-sm text-gray-600 arabic-text">وصف الطلب</Label>
                      <p className="text-gray-800 arabic-text text-right leading-relaxed">{selectedRequest.description}</p>
                    </div>
                    <div>
                      <Label className="text-sm text-gray-600 arabic-text">تاريخ التقديم</Label>
                      <p className="font-medium">{new Date(selectedRequest.date).toLocaleDateString('ar-SA')}</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Comments Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="arabic-text text-right text-lg">التعليقات والملاحظات</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {selectedRequest.comments.length > 0 ? (
                      <div className="space-y-3">
                        {selectedRequest.comments.map((comment: any) => (
                          <div key={comment.id} className="bg-gray-50 p-3 rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium text-sm arabic-text">{comment.author}</span>
                              <span className="text-xs text-gray-500">{comment.date}</span>
                            </div>
                            <p className="text-gray-800 arabic-text text-right">{comment.message}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 arabic-text text-center">لا توجد تعليقات بعد</p>
                    )}

                    {/* Add Comment */}
                    <div className="space-y-3 border-t pt-4">
                      <Label className="arabic-text text-right">إضافة تعليق جديد</Label>
                      <Textarea
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        placeholder="اكتب تعليقك هنا..."
                        className="text-right arabic-text"
                        rows={3}
                      />
                      <Button 
                        onClick={handleAddComment}
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={!commentText.trim()}
                      >
                        <Send className="h-4 w-4 ml-2" />
                        إضافة تعليق
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Actions */}
                {selectedRequest.status === 'pending' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="arabic-text text-right text-lg">إجراءات الطلب</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <Button 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => {
                            toast.success("تم الموافقة على الطلب");
                            setRequestModalOpen(false);
                          }}
                        >
                          <ThumbsUp className="h-4 w-4 ml-2" />
                          الموافقة على الطلب
                        </Button>
                        <Button 
                          variant="destructive"
                          onClick={() => {
                            toast.error("تم رفض الطلب");
                            setRequestModalOpen(false);
                          }}
                        >
                          <ThumbsDown className="h-4 w-4 ml-2" />
                          رفض الطلب
                        </Button>
                        <Button 
                          variant="outline"
                          className="bg-purple-50 hover:bg-purple-100"
                          onClick={() => handleMoveToVoting(selectedRequest.id)}
                        >
                          <Vote className="h-4 w-4 ml-2" />
                          نقل للتصويت العام
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Event Edit Modal */}
        <Dialog open={eventModalOpen} onOpenChange={setEventModalOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="arabic-text text-right text-xl text-[#0D2E57]">
                تحرير الفعالية
              </DialogTitle>
              <DialogDescription className="arabic-text text-right">
                تعديل تفاصيل الفعالية وإعداداتها بما في ذلك العدد الأقصى للمشاركين
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6" dir="rtl">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="arabic-text text-right">عنوان الفعالية</Label>
                  <Input
                    value={eventForm.title}
                    onChange={(e) => setEventForm({...eventForm, title: e.target.value})}
                    className="text-right arabic-text"
                  />
                </div>
                <div>
                  <Label className="arabic-text text-right">فئة الفعالية</Label>
                  <Select value={eventForm.category} onValueChange={(value) => setEventForm({...eventForm, category: value})}>
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر الفئة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="تقنية">تقنية</SelectItem>
                      <SelectItem value="أعمال">أعمال</SelectItem>
                      <SelectItem value="تدريب">تدريب</SelectItem>
                      <SelectItem value="ثقافية">ثقافية</SelectItem>
                      <SelectItem value="علمية">علمية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="arabic-text text-right">وصف الفعالية</Label>
                <Textarea
                  value={eventForm.description}
                  onChange={(e) => setEventForm({...eventForm, description: e.target.value})}
                  className="text-right arabic-text"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="arabic-text text-right">التاريخ</Label>
                  <Input
                    type="date"
                    value={eventForm.date}
                    onChange={(e) => setEventForm({...eventForm, date: e.target.value})}
                  />
                </div>
                <div>
                  <Label className="arabic-text text-right">الوقت</Label>
                  <Input
                    value={eventForm.time}
                    onChange={(e) => setEventForm({...eventForm, time: e.target.value})}
                    placeholder="09:00 ص"
                    className="text-right arabic-text"
                  />
                </div>
                <div>
                  <Label className="arabic-text text-right">المكان</Label>
                  <Input
                    value={eventForm.location}
                    onChange={(e) => setEventForm({...eventForm, location: e.target.value})}
                    className="text-right arabic-text"
                  />
                </div>
              </div>

              <div>
                <Label className="arabic-text text-right">العدد الأقصى للمشاركين</Label>
                <Input
                  type="number"
                  value={eventForm.maxParticipants}
                  onChange={(e) => setEventForm({...eventForm, maxParticipants: e.target.value})}
                  className="text-right"
                />
              </div>

              <div className="flex items-center justify-end space-x-4 space-x-reverse pt-4">
                <Button variant="outline" onClick={() => setEventModalOpen(false)}>
                  <X className="h-4 w-4 ml-2" />
                  إلغاء
                </Button>
                <Button onClick={handleSaveEvent} className="bg-[#0D2E57] hover:bg-[#0D2E57]/90">
                  <Save className="h-4 w-4 ml-2" />
                  حفظ التعديلات
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Announcement Modal */}
        <Dialog open={announcementModalOpen} onOpenChange={setAnnouncementModalOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle className="arabic-text text-right text-xl text-[#0D2E57]">
                إضافة إعلان جديد
              </DialogTitle>
              <DialogDescription className="arabic-text text-right">
                إنشاء إعلان جديد لعرضه في واجهة الأخبار مع إمكانية تحديد فئة الإعلان وإعداداته
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6" dir="rtl">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="arabic-text text-right">عنوان الإعلان</Label>
                  <Input
                    value={announcementForm.title}
                    onChange={(e) => setAnnouncementForm({...announcementForm, title: e.target.value})}
                    className="text-right arabic-text"
                  />
                </div>
                <div>
                  <Label className="arabic-text text-right">فئة الإعلان</Label>
                  <Select value={announcementForm.category} onValueChange={(value) => setAnnouncementForm({...announcementForm, category: value})}>
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر الفئة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="إنجازات">إنجازات</SelectItem>
                      <SelectItem value="فعاليات">فعاليات</SelectItem>
                      <SelectItem value="شراكات">شراكات</SelectItem>
                      <SelectItem value="بحوث علمية">بحوث علمية</SelectItem>
                      <SelectItem value="إنجازات طلابية">إنجازات طلابية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="arabic-text text-right">محتوى الإعلان</Label>
                <Textarea
                  value={announcementForm.content}
                  onChange={(e) => setAnnouncementForm({...announcementForm, content: e.target.value})}
                  className="text-right arabic-text"
                  rows={5}
                  placeholder="اكتب محتوى الإعلان هنا..."
                />
              </div>

              <div>
                <Label className="arabic-text text-right">رابط الصورة</Label>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Input
                    value={announcementForm.image}
                    onChange={(e) => setAnnouncementForm({...announcementForm, image: e.target.value})}
                    placeholder="https://example.com/image.jpg"
                    className="text-right"
                  />
                  <Button variant="outline" size="sm">
                    <Image className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex items-center space-x-3 space-x-reverse">
                <Switch
                  checked={announcementForm.isHot}
                  onCheckedChange={(checked) => setAnnouncementForm({...announcementForm, isHot: checked})}
                />
                <Label className="arabic-text text-right">إعلان عاجل</Label>
              </div>

              <div className="flex items-center justify-end space-x-4 space-x-reverse pt-4">
                <Button variant="outline" onClick={() => setAnnouncementModalOpen(false)}>
                  <X className="h-4 w-4 ml-2" />
                  إلغاء
                </Button>
                <Button onClick={handleSaveAnnouncement} className="bg-[#0D2E57] hover:bg-[#0D2E57]/90">
                  <Save className="h-4 w-4 ml-2" />
                  حفظ الإعلان
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}