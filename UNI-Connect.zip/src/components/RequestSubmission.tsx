import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { ArrowLeft, FileText, Send, Lightbulb, Users, Trophy, Heart, Code, Palette, BookOpen } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface RequestSubmissionProps {
  onBack: () => void;
  onRequestSuccess: () => void;
}

const colleges = [
  "College of Engineering",
  "College of Computer Science and Information Technology", 
  "College of Business Administration",
  "College of Medicine",
  "College of Science",
  "College of Arts and Humanities",
  "College of Education",
  "College of Law",
  "College of Pharmacy",
  "College of Dentistry"
];

const initiativeTypes = [
  { value: "technical", label: "Technical", icon: Code },
  { value: "volunteer", label: "Volunteer", icon: Heart },
  { value: "sports", label: "Sports", icon: Trophy },
  { value: "cultural", label: "Cultural", icon: Palette },
  { value: "technology", label: "Technology", icon: BookOpen },
  { value: "academic", label: "Academic", icon: Users },
  { value: "social", label: "Social", icon: Users },
  { value: "environmental", label: "Environmental", icon: Lightbulb },
  { value: "artistic", label: "Artistic Creative", icon: Palette },
  { value: "educational", label: "Educational", icon: BookOpen }
];

export function RequestSubmission({ onBack, onRequestSuccess }: RequestSubmissionProps) {
  const [selectedCollege, setSelectedCollege] = useState<string>("");
  const [studentId, setStudentId] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [initiativeType, setInitiativeType] = useState<string>("");
  const [ideaDescription, setIdeaDescription] = useState<string>("");
  const [partnerOrganization, setPartnerOrganization] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Required fields validation
    if (!selectedCollege || !studentId || !email || !initiativeType || !ideaDescription) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (studentId.length !== 9) {
      toast.error("University ID must be exactly 9 digits");
      return;
    }

    if (!email.includes("@") || !email.includes(".")) {
      toast.error("Please enter a valid email address");
      return;
    }

    if (ideaDescription.length > 500) {
      toast.error("Idea description must not exceed 500 characters");
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success("Your request has been submitted successfully!");
      
      // Reset form
      setSelectedCollege("");
      setStudentId("");
      setEmail("");
      setInitiativeType("");
      setIdeaDescription("");
      setPartnerOrganization("");
      
      // Return to main page after a short delay
      setTimeout(() => {
        toast.info("Returning to main page...");
        setTimeout(() => {
          onRequestSuccess();
        }, 800);
      }, 1500);
    }, 2000);
  };

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-4xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold text-[#0D2E57] flex items-center space-x-3">
            <FileText className="h-8 w-8" />
            <span>Submit Request</span>
          </h1>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-[#0D2E57]">
                  Submit Event or Initiative Request
                </CardTitle>
                <p className="text-gray-600 mt-2">
                  To submit a request, please fill in the following information correctly
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* College Selection - Required */}
                  <div className="space-y-2">
                    <Label className="block">
                      Select Your College Name *
                    </Label>
                    <Select value={selectedCollege} onValueChange={setSelectedCollege}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Choose your college" />
                      </SelectTrigger>
                      <SelectContent>
                        {colleges.map((college, index) => (
                          <SelectItem key={index} value={college}>
                            {college}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Student ID - Required */}
                  <div className="space-y-2">
                    <Label className="block">
                      University ID *
                    </Label>
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={studentId}
                      onChange={(e) => {
                        // Only allow numbers
                        const value = e.target.value.replace(/[^0-9]/g, '');
                        setStudentId(value);
                      }}
                      onKeyPress={(e) => {
                        // Prevent non-numeric characters
                        if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'Tab') {
                          e.preventDefault();
                        }
                      }}
                      placeholder="Enter your university ID (numbers only)"
                      maxLength={9}
                    />
                    <p className="text-xs text-gray-500">
                      Must contain only numbers (9 digits)
                    </p>
                  </div>

                  {/* University Email - Required */}
                  <div className="space-y-2">
                    <Label className="block">
                      University Email *
                    </Label>
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="example@stu.kau.edu.sa"
                    />
                  </div>

                  {/* Initiative Type - Required */}
                  <div className="space-y-2">
                    <Label className="block">
                      Select Initiative Type *
                    </Label>
                    <Select value={initiativeType} onValueChange={setInitiativeType}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Choose initiative type" />
                      </SelectTrigger>
                      <SelectContent>
                        {initiativeTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Idea Description - Required */}
                  <div className="space-y-2">
                    <Label className="block">
                      Brief Idea Description (500 characters maximum) *
                    </Label>
                    <Textarea
                      value={ideaDescription}
                      onChange={(e) => setIdeaDescription(e.target.value)}
                      placeholder="Write a brief description of your idea or initiative..."
                      className="resize-none"
                      rows={4}
                      maxLength={500}
                    />
                    <p className="text-sm text-gray-500">
                      {ideaDescription.length}/500 characters
                    </p>
                  </div>

                  {/* Partner Organization - Optional */}
                  <div className="space-y-2">
                    <Label className="block">
                      Partner Organization Name (if any)
                    </Label>
                    <Input
                      type="text"
                      value={partnerOrganization}
                      onChange={(e) => setPartnerOrganization(e.target.value)}
                      placeholder="Example: Tech company, charity organization, educational institution"
                    />
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit"
                    disabled={isSubmitting || !selectedCollege || !studentId || !email || !initiativeType || !ideaDescription}
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center justify-center space-x-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        <span>Submitting...</span>
                      </span>
                    ) : (
                      <span className="flex items-center justify-center space-x-2">
                        <Send className="h-4 w-4" />
                        <span>Submit Request</span>
                      </span>
                    )}
                  </Button>

                  <p className="text-xs text-gray-500 text-center leading-relaxed">
                    By clicking "Submit Request", you confirm the accuracy of the entered data and agree to the initiative submission terms
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Instructions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-[#0D2E57]">
                  Important Guidelines
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <p className="text-sm leading-relaxed">
                      Make sure to enter your correct information to ensure we can contact you
                    </p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <p className="text-sm leading-relaxed">
                      Your request will be reviewed within 5-7 business days
                    </p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <p className="text-sm leading-relaxed">
                      You will receive a response via your registered university email
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Initiative Types Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-[#0D2E57]">
                  Initiative Types
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {initiativeTypes.slice(0, 6).map((type) => {
                    const IconComponent = type.icon;
                    return (
                      <div key={type.value} className="flex items-center space-x-2">
                        <IconComponent className="h-4 w-4 text-gray-600" />
                        <span className="text-sm">{type.label}</span>
                      </div>
                    );
                  })}
                </div>
                <p className="text-xs text-gray-500 mt-3">
                  And other types can be selected from the list
                </p>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-[#0D2E57]">
                  For Inquiries
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm">
                    <strong>Email:</strong><br />
                    initiatives@kau.edu.sa
                  </p>
                  <p className="text-sm">
                    <strong>Phone:</strong><br />
                    012-6400000 Ext. 12345
                  </p>
                  <p className="text-sm">
                    <strong>Working Hours:</strong><br />
                    Sunday - Thursday: 8:00 AM - 4:00 PM
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}