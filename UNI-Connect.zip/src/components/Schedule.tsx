import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Calendar, Clock, MapPin } from "lucide-react";

export function Schedule() {
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const timeSlots = [
    "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", 
    "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
  ];

  const schedule = {
    Monday: [
      { time: "9:00 AM", course: "CS 101", name: "Intro to Computer Science", location: "Science Bldg, Room 204", duration: 1 },
      { time: "4:00 PM", course: "PHYS 150", name: "General Physics I", location: "Physics Bldg, Lab 301", duration: 1.5 }
    ],
    Tuesday: [
      { time: "11:00 AM", course: "ENG 102", name: "English Literature", location: "Liberal Arts, Room 210", duration: 1.5 },
      { time: "2:00 PM", course: "MATH 201", name: "Calculus II", location: "Math Bldg, Room 150", duration: 1.5 }
    ],
    Wednesday: [
      { time: "9:00 AM", course: "CS 101", name: "Intro to Computer Science", location: "Science Bldg, Room 204", duration: 1 },
      { time: "4:00 PM", course: "PHYS 150", name: "General Physics I", location: "Physics Bldg, Lab 301", duration: 1.5 }
    ],
    Thursday: [
      { time: "11:00 AM", course: "ENG 102", name: "English Literature", location: "Liberal Arts, Room 210", duration: 1.5 },
      { time: "2:00 PM", course: "MATH 201", name: "Calculus II", location: "Math Bldg, Room 150", duration: 1.5 }
    ],
    Friday: [
      { time: "9:00 AM", course: "CS 101", name: "Intro to Computer Science", location: "Science Bldg, Room 204", duration: 1 },
      { time: "4:00 PM", course: "PHYS 150", name: "General Physics I", location: "Physics Bldg, Lab 301", duration: 1.5 }
    ]
  };

  const upcomingClasses = [
    { course: "CS 101", name: "Intro to Computer Science", time: "Tomorrow, 9:00 AM", location: "Science Bldg, Room 204" },
    { course: "ENG 102", name: "English Literature", time: "Tomorrow, 11:00 AM", location: "Liberal Arts, Room 210" },
    { course: "MATH 201", name: "Calculus II", time: "Tomorrow, 2:00 PM", location: "Math Bldg, Room 150" }
  ];

  const getCourseColor = (course: string) => {
    const colors: { [key: string]: string } = {
      "CS 101": "bg-blue-100 border-blue-200 text-blue-800",
      "MATH 201": "bg-green-100 border-green-200 text-green-800",
      "PHYS 150": "bg-purple-100 border-purple-200 text-purple-800",
      "ENG 102": "bg-orange-100 border-orange-200 text-orange-800"
    };
    return colors[course] || "bg-gray-100 border-gray-200 text-gray-800";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Class Schedule</h1>
          <p className="text-muted-foreground">Your weekly class schedule and upcoming classes.</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm">
            <Calendar className="h-4 w-4 mr-2" />
            Export Calendar
          </Button>
          <Badge variant="secondary">Week of Sept 2-6, 2025</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Schedule</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-6 gap-2 text-sm">
                <div className="font-medium p-2">Time</div>
                {days.map(day => (
                  <div key={day} className="font-medium p-2 text-center">{day.slice(0, 3)}</div>
                ))}
                
                {timeSlots.map(time => (
                  <div key={time} className="contents">
                    <div className="p-2 text-xs text-muted-foreground border-r">{time}</div>
                    {days.map(day => {
                      const daySchedule = schedule[day as keyof typeof schedule] || [];
                      const classAtTime = daySchedule.find(cls => cls.time === time);
                      
                      return (
                        <div key={`${day}-${time}`} className="p-1 min-h-[60px] border-b border-border/50">
                          {classAtTime && (
                            <div className={`p-2 rounded text-xs ${getCourseColor(classAtTime.course)} border`}>
                              <div className="font-medium">{classAtTime.course}</div>
                              <div className="truncate">{classAtTime.name}</div>
                              <div className="flex items-center mt-1">
                                <MapPin className="h-3 w-3 mr-1" />
                                <span className="truncate">{classAtTime.location.split(',')[0]}</span>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Classes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {upcomingClasses.map((cls, index) => (
                <div key={index} className="p-3 bg-secondary/50 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline" className="text-xs">{cls.course}</Badge>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      {cls.time.split(',')[1]}
                    </div>
                  </div>
                  <h4 className="text-sm font-medium">{cls.name}</h4>
                  <div className="flex items-center text-xs text-muted-foreground mt-1">
                    <MapPin className="h-3 w-3 mr-1" />
                    {cls.location}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Classes this week</span>
                <span className="font-medium">12</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Total class hours</span>
                <span className="font-medium">18</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Free time slots</span>
                <span className="font-medium">38</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Busiest day</span>
                <span className="font-medium">Tuesday</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}