import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { CalendarDays, Clock, BookOpen, TrendingUp } from "lucide-react";

export function Dashboard() {
  const upcomingAssignments = [
    { id: 1, title: "Computer Science Essay", course: "CS 101", dueDate: "2025-09-05", priority: "high" },
    { id: 2, title: "Math Problem Set", course: "MATH 201", dueDate: "2025-09-07", priority: "medium" },
    { id: 3, title: "Physics Lab Report", course: "PHYS 150", dueDate: "2025-09-10", priority: "low" },
  ];

  const todayClasses = [
    { id: 1, name: "Computer Science 101", time: "9:00 AM - 10:30 AM", room: "Room 204", building: "Science Building" },
    { id: 2, name: "Mathematics 201", time: "2:00 PM - 3:30 PM", room: "Room 150", building: "Math Building" },
    { id: 3, name: "Physics 150", time: "4:00 PM - 5:30 PM", room: "Lab 301", building: "Physics Building" },
  ];

  const courseProgress = [
    { name: "Computer Science 101", progress: 75, grade: "A-" },
    { name: "Mathematics 201", progress: 82, grade: "B+" },
    { name: "Physics 150", progress: 68, grade: "B" },
    { name: "English Literature", progress: 90, grade: "A" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Welcome back, Sarah!</h1>
          <p className="text-muted-foreground">Here's what's happening with your studies today.</p>
        </div>
        <Badge variant="secondary" className="text-sm">
          Fall 2025 Semester
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Credits</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">16</div>
            <p className="text-xs text-muted-foreground">4 courses enrolled</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">GPA</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">3.7</div>
            <p className="text-xs text-muted-foreground">+0.2 from last semester</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Today's Classes</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{todayClasses.length}</div>
            <p className="text-xs text-muted-foreground">Next class at 9:00 AM</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Assignments Due</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{upcomingAssignments.length}</div>
            <p className="text-xs text-muted-foreground">This week</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Today's Classes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {todayClasses.map((classItem) => (
              <div key={classItem.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                <div>
                  <h4>{classItem.name}</h4>
                  <p className="text-sm text-muted-foreground">{classItem.room}, {classItem.building}</p>
                </div>
                <div className="text-sm">{classItem.time}</div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Assignments</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {upcomingAssignments.map((assignment) => (
              <div key={assignment.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                <div className="flex-1">
                  <h4>{assignment.title}</h4>
                  <p className="text-sm text-muted-foreground">{assignment.course}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge
                    variant={assignment.priority === "high" ? "destructive" : assignment.priority === "medium" ? "default" : "secondary"}
                  >
                    {assignment.priority}
                  </Badge>
                  <span className="text-sm">{assignment.dueDate}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Course Progress</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {courseProgress.map((course, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between items-center">
                <span>{course.name}</span>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">{course.grade}</Badge>
                  <span className="text-sm text-muted-foreground">{course.progress}%</span>
                </div>
              </div>
              <Progress value={course.progress} className="h-2" />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}