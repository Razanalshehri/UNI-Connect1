import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { 
  ArrowLeft, 
  Calendar, 
  MapPin, 
  Music, 
  BookOpen, 
  Trophy, 
  Users, 
  Heart,
  Palette,
  Gamepad2,
  Briefcase,
  GraduationCap
} from "lucide-react";

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  icon: any;
  bgColor: string;
}

interface EventsPageProps {
  onSelectEvent: (event: Event) => void;
  onBack: () => void;
}

const mockEvents: Event[] = [
  {
    id: "1",
    title: "Technology Innovation Exhibition",
    description: "Annual exhibition showcasing student technical and innovative projects",
    date: "2024-03-15",
    location: "Main Hall",
    icon: Briefcase,
    bgColor: "bg-blue-500"
  },
  {
    id: "2", 
    title: "Entrepreneurship Conference",
    description: "Conference featuring elite entrepreneurs and investors",
    date: "2024-03-20",
    location: "Main Hall",
    icon: Trophy,
    bgColor: "bg-green-500"
  },
  {
    id: "3",
    title: "Artificial Intelligence Workshop", 
    description: "Training workshop on AI fundamentals and machine learning",
    date: "2024-03-25",
    location: "Computer Lab",
    icon: GraduationCap,
    bgColor: "bg-purple-500"
  },
  {
    id: "4",
    title: "Annual Programming Competition",
    description: "Programming challenge competition for students of all levels",
    date: "2024-04-01",
    location: "College of Computing",
    icon: Gamepad2,
    bgColor: "bg-orange-500"
  },
  {
    id: "5",
    title: "Open Career Day",
    description: "Opportunity to connect with company representatives and explore job opportunities",
    date: "2024-04-10", 
    location: "Main Square",
    icon: Users,
    bgColor: "bg-teal-500"
  },
  {
    id: "6",
    title: "Culture and Arts Festival",
    description: "Cultural event featuring art exhibitions and musical performances",
    date: "2024-04-15",
    location: "University Theater",
    icon: Palette,
    bgColor: "bg-pink-500"
  },
  {
    id: "7",
    title: "Mental Health Awareness Seminar",
    description: "Educational seminar on the importance of mental health for students",
    date: "2024-04-20",
    location: "Lecture Hall",
    icon: Heart,
    bgColor: "bg-red-500"
  },
  {
    id: "8",
    title: "Scientific Research Conference",
    description: "Conference to present scientific research by students and faculty members",
    date: "2024-04-25",
    location: "Conference Center",
    icon: BookOpen,
    bgColor: "bg-indigo-500"
  }
];

export function EventsPage({ onSelectEvent, onBack }: EventsPageProps) {
  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-6xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold text-[#0D2E57]">
            University Events
          </h1>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockEvents.map((event) => {
            const IconComponent = event.icon;
            return (
              <Card 
                key={event.id}
                className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
                onClick={() => onSelectEvent(event)}
              >
                <CardContent className="p-6">
                  <div className="flex flex-col space-y-4">
                    {/* Icon and Title */}
                    <div className="flex items-center">
                      <div className={`p-3 ${event.bgColor} rounded-xl mr-4`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-800 flex-1">
                        {event.title}
                      </h3>
                    </div>

                    {/* Description */}
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {event.description}
                    </p>

                    {/* Date and Location */}
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-500">
                          {new Date(event.date).toLocaleDateString('en-US')}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-500">
                          {event.location}
                        </span>
                      </div>
                    </div>

                    {/* Register Button */}
                    <Button 
                      className="w-full bg-[#0D2E57] hover:bg-[#0D2E57]/90 text-white py-2 rounded-lg"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectEvent(event);
                      }}
                    >
                      <span>Register Now</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}