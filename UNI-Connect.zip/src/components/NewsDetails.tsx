import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { ArrowRight, Calendar, Tag, Share2, Eye, ThumbsUp } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  content: string;
  date: string;
  category: string;
  image: string;
}

interface NewsDetailsProps {
  news: NewsItem;
  onBack: () => void;
}

export function NewsDetails({ news, onBack }: NewsDetailsProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Achievements":
        return "bg-yellow-100 text-yellow-800";
      case "Events":
        return "bg-blue-100 text-blue-800";
      case "Partnerships":
        return "bg-green-100 text-green-800";
      case "Student Achievements":
        return "bg-purple-100 text-purple-800";
      case "Scientific Research":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-4xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2"
            >
              <ArrowRight className="h-4 w-4" />
              <span>Back to News</span>
            </Button>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <Card className="overflow-hidden">
          {/* Hero Image */}
          <div className="aspect-[16/9] relative overflow-hidden">
            <ImageWithFallback
              src={news.image}
              alt={news.title}
              className="w-full h-full object-cover"
            />
            {/* Category Badge */}
            <div className={`absolute top-6 left-6 px-4 py-2 rounded-full font-medium ${getCategoryColor(news.category)} backdrop-blur-sm`}>
              <div className="flex items-center space-x-2">
                <Tag className="h-4 w-4" />
                <span>{news.category}</span>
              </div>
            </div>
          </div>

          <CardContent className="p-8">
            <div className="space-y-6">
              {/* Meta Information */}
              <div className="flex items-center justify-between text-sm text-gray-500 border-b border-gray-200 pb-4">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>
                      {new Date(news.date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>1,247 views</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-red-500">
                    <ThumbsUp className="h-4 w-4 mr-1" />
                    <span>156</span>
                  </Button>
                </div>
              </div>

              {/* Title */}
              <h1 className="text-3xl font-bold leading-relaxed text-gray-800">
                {news.title}
              </h1>

              {/* Summary */}
              <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-500">
                <p className="text-lg leading-relaxed text-blue-900 font-medium">
                  {news.summary}
                </p>
              </div>

              {/* Content */}
              <div className="prose prose-lg max-w-none">
                <div className="leading-relaxed text-gray-700 whitespace-pre-line">
                  {news.content}
                </div>
              </div>

              {/* Tags */}
              <div className="pt-6 border-t border-gray-200">
                <div className="flex items-center space-x-3">
                  <span className="text-sm text-gray-500">Keywords:</span>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                      #King_Abdulaziz_University
                    </span>
                    <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                      #{news.category.replace(/\s/g, '_')}
                    </span>
                    <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                      #University_News
                    </span>
                  </div>
                </div>
              </div>

              {/* Share Section */}
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-gray-800">
                    Share this news
                  </h3>
                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-blue-600 border-blue-600 hover:bg-blue-600 hover:text-white"
                    >
                      Twitter
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-blue-800 border-blue-800 hover:bg-blue-800 hover:text-white"
                    >
                      Facebook
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-green-600 border-green-600 hover:bg-green-600 hover:text-white"
                    >
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-[#0D2E57] text-white p-6 rounded-lg">
                <div>
                  <h3 className="font-medium mb-3">
                    For More Information
                  </h3>
                  <div className="space-y-2 text-sm">
                    <p>
                      <strong>Media and Communications Office:</strong><br />
                      Email: media@kau.edu.sa<br />
                      Phone: 012-6400000 Ext. 11111
                    </p>
                    <p className="text-blue-200">
                      Follow us on social media for the latest news and updates
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Related News */}
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-6 text-[#0D2E57]">
            Related News
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex space-x-4">
                  <div className="w-20 h-20 bg-gray-200 rounded-lg flex-shrink-0"></div>
                  <div className="flex-1">
                    <h3 className="font-medium text-sm leading-relaxed">
                      Opening of the New Innovation Center at the University
                    </h3>
                    <p className="text-gray-500 text-xs mt-1">
                      3 days ago
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex space-x-4">
                  <div className="w-20 h-20 bg-gray-200 rounded-lg flex-shrink-0"></div>
                  <div className="flex-1">
                    <h3 className="font-medium text-sm leading-relaxed">
                      Memorandum of Understanding Signed with Oxford University
                    </h3>
                    <p className="text-gray-500 text-xs mt-1">
                      5 days ago
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}