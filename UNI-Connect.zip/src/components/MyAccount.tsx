import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Switch } from "./ui/switch";
import { 
  User, 
  Settings, 
  Bell, 
  Shield, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Mail,
  Phone,
  Calendar,
  GraduationCap,
  Heart,
  BarChart3,
  MapPin
} from "lucide-react";

export function MyAccount() {
  const user = {
    name: "Sarah Johnson",
    email: "sarah.johnson@university.edu",
    studentId: "SU2024001234",
    role: "Student",
    avatar: "https://images.unsplash.com/photo-1568880893176-fb2bdab44e41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwcHJvZmlsZSUyMHBob3RvfGVufDF8fHx8MTc1NjY2MDI2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    joinDate: "Fall 2022",
    major: "Computer Science"
  };

  const stats = [
    { label: "Events Attended", value: "24", icon: Calendar },
    { label: "Polls Participated", value: "12", icon: BarChart3 },
    { label: "Ideas Submitted", value: "3", icon: Heart },
    { label: "Buildings Visited", value: "18", icon: MapPin }
  ];

  const menuItems = [
    {
      section: "Account",
      items: [
        { label: "Profile Information", icon: User, description: "Update your personal details" },
        { label: "Academic Information", icon: GraduationCap, description: "View your academic progress" },
        { label: "Contact Information", icon: Mail, description: "Manage your contact details" }
      ]
    },
    {
      section: "Preferences",
      items: [
        { label: "Notifications", icon: Bell, description: "Manage notification settings" },
        { label: "Privacy Settings", icon: Shield, description: "Control your privacy preferences" },
        { label: "App Settings", icon: Settings, description: "Customize your app experience" }
      ]
    },
    {
      section: "Support",
      items: [
        { label: "Help Center", icon: HelpCircle, description: "Get help and support" },
        { label: "Feedback", icon: Heart, description: "Share your thoughts with us" }
      ]
    }
  ];

  const notificationSettings = [
    { label: "Event Reminders", enabled: true },
    { label: "New Poll Notifications", enabled: true },
    { label: "Announcement Alerts", enabled: false },
    { label: "Idea Status Updates", enabled: true }
  ];

  return (
    <div className="pb-20 space-y-6">
      {/* Header */}
      <div className="px-4 pt-4">
        <h1 className="mb-2">My Account</h1>
        <p className="text-muted-foreground text-sm">
          Manage your profile and app preferences
        </p>
      </div>

      {/* Profile Card */}
      <div className="px-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h2 className="font-medium">{user.name}</h2>
                <p className="text-sm text-muted-foreground">{user.email}</p>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge variant="secondary">{user.role}</Badge>
                  <span className="text-xs text-muted-foreground">Since {user.joinDate}</span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Student ID: {user.studentId}</p>
                  <p className="text-sm text-muted-foreground">Major: {user.major}</p>
                </div>
                <Button variant="outline" size="sm">
                  Edit Profile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Activity Stats */}
      <div className="px-4">
        <h2 className="mb-4">Your Activity</h2>
        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <Card key={index}>
                <CardContent className="p-4 text-center">
                  <IconComponent className="h-6 w-6 mx-auto text-primary mb-2" />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Quick Settings */}
      <div className="px-4">
        <h2 className="mb-4">Quick Settings</h2>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Notifications</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {notificationSettings.map((setting, index) => (
              <div key={index} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{setting.label}</p>
                </div>
                <Switch defaultChecked={setting.enabled} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Menu Sections */}
      {menuItems.map((section, sectionIndex) => (
        <div key={sectionIndex} className="px-4">
          <h2 className="mb-4">{section.section}</h2>
          <Card>
            <CardContent className="p-0">
              {section.items.map((item, itemIndex) => {
                const IconComponent = item.icon;
                return (
                  <button
                    key={itemIndex}
                    className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors first:rounded-t-lg last:rounded-b-lg border-b last:border-b-0"
                  >
                    <div className="flex items-center space-x-3">
                      <IconComponent className="h-5 w-5 text-muted-foreground" />
                      <div className="text-left">
                        <p className="text-sm font-medium">{item.label}</p>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </button>
                );
              })}
            </CardContent>
          </Card>
        </div>
      ))}

      {/* User Role Badge */}
      <div className="px-4">
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-primary">Student Access</h3>
                <p className="text-sm text-muted-foreground">
                  You have full access to all student features
                </p>
              </div>
              <Badge className="bg-primary text-primary-foreground">
                Verified
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Logout */}
      <div className="px-4">
        <Card>
          <CardContent className="p-0">
            <button className="w-full flex items-center justify-between p-4 hover:bg-destructive/5 transition-colors rounded-lg text-destructive">
              <div className="flex items-center space-x-3">
                <LogOut className="h-5 w-5" />
                <span className="text-sm font-medium">Sign Out</span>
              </div>
              <ChevronRight className="h-4 w-4" />
            </button>
          </CardContent>
        </Card>
      </div>

      {/* App Info */}
      <div className="px-4 text-center">
        <div className="space-y-1 text-xs text-muted-foreground">
          <p>UNI Connect v2.1.0</p>
          <p>© 2025 University Digital Services</p>
        </div>
      </div>
    </div>
  );
}