import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { ArrowLeft, Award, Trophy, Users, Globe, Star, Zap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  content: string;
  date: string;
  category: string;
  image: string;
}

interface NewsPageProps {
  onSelectNews: (news: NewsItem) => void;
  onBack: () => void;
}

const newsData: NewsItem[] = [
  {
    id: "1",
    title: "University Ranks First Nationally in Global University Rankings",
    summary: "The university achieved a historic milestone by securing first place nationally in the 2024 Global University Rankings",
    content: "In a remarkable historic achievement, the university secured first place nationally in Saudi Arabia in the QS World University Rankings 2024. This accomplishment comes as a result of continuous efforts in developing scientific research, education quality, and innovation.\n\nThe university excelled in several key areas including education quality, scientific research, international collaboration, and graduate employability. It also received high scores in sustainability and social responsibility indicators.\n\nThe university rector praised this achievement stating: 'This progress reflects our continuous commitment to providing high-quality education and conducting distinguished scientific research that serves society and the nation.'\n\nThis achievement comes within the university's strategic plan 2030, which aims to establish its position as a leading educational and research institution at regional and global levels.",
    date: "2024-12-25",
    category: "Achievements",
    image: "https://images.unsplash.com/photo-1563290331-f295b4fb2fd3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYXdhcmQlMjBjZXJlbW9ueXxlbnwxfHx8fDE3NTY3NDcxOTR8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: "2", 
    title: "Graduation Ceremony for the 45th Class of University Students",
    summary: "The university celebrated the graduation of more than 8,000 students from various colleges and specializations",
    content: "The university held a magnificent graduation ceremony for its 45th class of students, where more than 8,000 male and female students graduated from various colleges and specializations.\n\nThe ceremony was held in the university's main auditorium with the attendance of the university rector, vice-rectors, college deans, and faculty members, in addition to the graduates' parents.\n\nDuring the ceremony, outstanding students from each college were honored, and the university rector delivered a speech praising the graduates' achievements and urging them to contribute to serving the nation and society.\n\nA documentary film was also shown highlighting the major achievements of this class during their years of study and the scientific and cultural activities they participated in.\n\nThe graduates expressed their pride in belonging to this prestigious university and their aspirations to contribute to achieving Saudi Vision 2030.",
    date: "2024-12-20",
    category: "Events",
    image: "https://images.unsplash.com/photo-1738949538943-e54722a44ffc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGNlcmVtb255fGVufDF8fHx8MTc1NjY2NzQ5OXww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: "3",
    title: "Strategic Partnership Agreement Signed with Harvard University",
    summary: "The university signed a partnership agreement with Harvard University for academic and research collaboration",
    content: "The university signed a strategic partnership agreement with the prestigious Harvard University in the United States, in an important step to enhance academic and research cooperation.\n\nThe agreement includes several main axes including the exchange of faculty members and researchers, development of joint graduate programs, and collaboration in advanced scientific research projects.\n\nThe agreement also stipulates the establishment of student exchange programs for outstanding students and the development of joint curricula in the fields of medicine, engineering, and computer science.\n\nThe university rector confirmed that this partnership comes within the university's strategy to open up to the world's best universities and attract distinguished expertise.\n\nThe first fruits of this partnership are expected to begin during the next academic year through an academic exchange program that will benefit 50 male and female students from the university.",
    date: "2024-12-18",
    category: "Partnerships",
    image: "https://images.unsplash.com/photo-1650316678805-03bcabda3f30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwaW50ZXJuYXRpb25hbCUyMHBhcnRuZXJzaGlwfGVufDF8fHx8MTc1Njc0NzIwMHww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: "4",
    title: "University Student Team Wins Best Innovation Award at Global GITEX Exhibition",
    summary: "A team from the Computer Science College achieved first place in the technical innovation competition",
    content: "A team of students from the College of Computer Science and Information Technology achieved a distinguished accomplishment by winning the Best Innovation Award at the global GITEX technology exhibition in Dubai.\n\nThe team consisting of 5 students developed a smart application using advanced algorithms to analyze medical data and assist doctors in early disease diagnosis.\n\nThe team competed with more than 200 projects from prestigious international universities and managed to impress the specialized judging panel with their advanced innovation and practical application.\n\nThe project was supervised by Dr. Ahmed Al-Saadi from the Computer Science Department, who confirmed that this achievement reflects the students' distinguished level and the advanced research capabilities at the university.\n\nThe team received a monetary prize of $100,000 and was invited to present their project at several international technology conferences.\n\nTeam members expressed their pride in representing the university and the Kingdom at this important international forum.",
    date: "2024-12-15",
    category: "Student Achievements",
    image: "https://images.unsplash.com/photo-1741529189563-5f3eb1253eb7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwaW5ub3ZhdGlvbiUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzU2NzQ3MjA0fDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: "5",
    title: "New Scientific Discovery in Renewable Energy Field at Engineering College",
    summary: "A research team from the Engineering College develops new technology to improve solar panel efficiency by 40%",
    content: "A research team from the College of Engineering at King Abdulaziz University achieved an important scientific breakthrough in the field of renewable energy, managing to develop a new technology that increases solar panel efficiency by up to 40%.\n\nThe research led by Dr. Mohammed Al-Shahri from the Electrical Engineering Department focused on developing new nanomaterials that improve solar panels' ability to absorb and convert light into electrical energy.\n\nThe research was published in the prestigious Nature Energy journal and received wide acclaim from the international scientific community.\n\nA patent was registered for the new technology, and negotiations are underway with global companies for its commercial application.\n\nThe university rector confirmed that this discovery contributes to achieving the goals of Saudi Vision 2030 in the field of renewable energy and environmental sustainability.\n\nThis achievement also reflects the university's commitment to supporting applied research that serves sustainable development and the national economy.",
    date: "2024-12-12",
    category: "Scientific Research",
    image: "https://images.unsplash.com/photo-1659080907111-7c726e435a28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwcmVzZWFyY2glMjBhY2hpZXZlbWVudHxlbnwxfHx8fDE3NTY3NDcxOTd8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: "6",
    title: "Medical College Student Wins Best Research Award at International Medical Conference",
    summary: "Student Sarah Ahmed receives first place in the student medical research competition",
    content: "Student Sarah Ahmed from the College of Medicine at King Abdulaziz University achieved an excellent accomplishment by winning the Best Student Research Award at the International Medical Conference held in London.\n\nSarah's research addressed developing a new treatment for heart diseases using stem cells, and impressed the specialized judging panel.\n\nMore than 500 medical students from 40 countries around the world participated in the conference, and Sarah managed to excel over all competitors.\n\nThe research was supervised by Dr. Abdulrahman Al-Malki from the Cardiology Department, who praised the student's excellence and diligence.\n\nSarah received a scholarship to complete her graduate studies at one of the prestigious British universities.\n\nThe student expressed her pride in representing the university and the nation at this important scientific forum and confirmed her determination to continue scientific research to serve humanity.",
    date: "2024-12-10",
    category: "Student Achievements",
    image: "https://images.unsplash.com/photo-1756272577466-50610762ed98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwc3R1ZGVudCUyMGFjaGlldmVtZW50fGVufDF8fHx8MTc1Njc0NzIwOHww&ixlib=rb-4.1.0&q=80&w=1080"
  }
];

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "Achievements":
      return Trophy;
    case "Events":
      return Users;
    case "Partnerships":
      return Globe;
    case "Student Achievements":
      return Star;
    case "Scientific Research":
      return Zap;
    default:
      return Award;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case "Achievements":
      return "bg-yellow-100 text-yellow-800";
    case "Events":
      return "bg-blue-100 text-blue-800";
    case "Partnerships":
      return "bg-green-100 text-green-800";
    case "Student Achievements":
      return "bg-purple-100 text-purple-800";
    case "Scientific Research":
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

export function NewsPage({ onSelectNews, onBack }: NewsPageProps) {
  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #ffffff 0%, #e6f3ff 100%)' 
    }}>
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-3xl font-bold text-[#0D2E57] flex items-center space-x-3">
            <Award className="h-8 w-8" />
            <span>News of Our Greatest Achievements</span>
          </h1>
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {newsData.map((news) => {
            const IconComponent = getCategoryIcon(news.category);
            const categoryColor = getCategoryColor(news.category);
            
            return (
              <Card 
                key={news.id}
                className="overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
                onClick={() => onSelectNews(news)}
              >
                <div className="aspect-[4/3] relative overflow-hidden">
                  <ImageWithFallback
                    src={news.image}
                    alt={news.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                  {/* Category Badge */}
                  <div className={`absolute top-4 left-4 px-3 py-1 rounded-full text-sm font-medium ${categoryColor} backdrop-blur-sm`}>
                    <div className="flex items-center space-x-1">
                      <IconComponent className="h-3 w-3" />
                      <span>{news.category}</span>
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {/* Date */}
                    <div className="text-sm text-gray-500">
                      {new Date(news.date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </div>
                    
                    {/* Title */}
                    <h3 className="text-lg font-semibold leading-relaxed text-gray-800 line-clamp-2">
                      {news.title}
                    </h3>
                    
                    {/* Summary */}
                    <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">
                      {news.summary}
                    </p>
                    
                    {/* Read More Button */}
                    <div className="flex justify-start pt-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[#0D2E57] hover:text-[#0D2E57]/80 p-0 h-auto"
                      >
                        Read More →
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Load More Button */}
        <div className="text-center mt-12">
          <Button 
            variant="outline"
            className="px-8 py-3 text-[#0D2E57] border-[#0D2E57] hover:bg-[#0D2E57] hover:text-white"
          >
            Load More News
          </Button>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
          <Card className="text-center p-6">
            <Trophy className="h-8 w-8 text-[#0D2E57] mx-auto mb-2" />
            <div>
              <p className="text-2xl font-bold text-gray-800">25</p>
              <p className="text-gray-600 text-sm">International Awards</p>
            </div>
          </Card>
          
          <Card className="text-center p-6">
            <Users className="h-8 w-8 text-[#0D2E57] mx-auto mb-2" />
            <div>
              <p className="text-2xl font-bold text-gray-800">150</p>
              <p className="text-gray-600 text-sm">International Partnerships</p>
            </div>
          </Card>
          
          <Card className="text-center p-6">
            <Star className="h-8 w-8 text-[#0D2E57] mx-auto mb-2" />
            <div>
              <p className="text-2xl font-bold text-gray-800">500</p>
              <p className="text-gray-600 text-sm">Research Publications</p>
            </div>
          </Card>
          
          <Card className="text-center p-6">
            <Zap className="h-8 w-8 text-[#0D2E57] mx-auto mb-2" />
            <div>
              <p className="text-2xl font-bold text-gray-800">50</p>
              <p className="text-gray-600 text-sm">Patents</p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}