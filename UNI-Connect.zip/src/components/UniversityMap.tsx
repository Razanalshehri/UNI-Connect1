import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { ArrowLeft, MapPin, Navigation, Building, Users, Search, Map, Route, Clock, Compass } from "lucide-react";

interface UniversityMapProps {
  onBack: () => void;
}

const collegesAndBuildings = [
  {
    name: "College of Engineering",
    buildings: [
      { number: "1", name: "Civil Engineering Building", rooms: ["101", "102", "103", "201", "202", "301"], x: 150, y: 120, z: 80 },
      { number: "2", name: "Electrical Engineering Building", rooms: ["A1", "A2", "B1", "B2", "C1"], x: 200, y: 140, z: 70 },
      { number: "3", name: "Mechanical Engineering Building", rooms: ["M101", "M102", "M201", "M301"], x: 250, y: 160, z: 90 }
    ],
    color: "orange",
    centerX: 200,
    centerY: 140
  },
  {
    name: "College of Computer Science and Information Technology",
    buildings: [
      { number: "4", name: "Computer Science Building", rooms: ["CS101", "CS102", "CS201", "LAB1", "LAB2"], x: 320, y: 200, z: 100 },
      { number: "5", name: "Information Technology Building", rooms: ["IT101", "IT102", "IT201", "SERVER"], x: 370, y: 220, z: 85 }
    ],
    color: "purple",
    centerX: 345,
    centerY: 210
  },
  {
    name: "College of Business Administration",
    buildings: [
      { number: "6", name: "Business Administration Building", rooms: ["BA101", "BA102", "BA201", "BA301"], x: 180, y: 300, z: 75 }
    ],
    color: "green",
    centerX: 180,
    centerY: 300
  },
  {
    name: "College of Medicine",
    buildings: [
      { number: "7", name: "Basic Medicine Building", rooms: ["MED101", "MED102", "LAB1", "LAB2"], x: 400, y: 350, z: 95 },
      { number: "8", name: "University Hospital", rooms: ["WARD1", "WARD2", "ER", "ICU"], x: 450, y: 380, z: 120 }
    ],
    color: "red",
    centerX: 425,
    centerY: 365
  },
  {
    name: "University Complex",
    buildings: [
      { number: "Main Building", name: "Main Hall", rooms: ["Reception", "Meeting Room", "Library"], x: 300, y: 250, z: 110 },
      { number: "Services Building", name: "Student Services", rooms: ["Student Affairs", "Admissions & Registration", "Financial Affairs"], x: 280, y: 280, z: 65 }
    ],
    color: "blue",
    centerX: 290,
    centerY: 265
  }
];

// Starting point (entrance)
const START_POINT = { x: 50, y: 400 };

export function UniversityMap({ onBack }: UniversityMapProps) {
  const [selectedCollege, setSelectedCollege] = useState<string>("");
  const [selectedBuilding, setSelectedBuilding] = useState<string>("");
  const [selectedRoom, setSelectedRoom] = useState<string>("");
  const [showMap, setShowMap] = useState(false);
  const [walkingAnimation, setWalkingAnimation] = useState(false);
  const [pathProgress, setPathProgress] = useState(0);

  const selectedCollegeData = collegesAndBuildings.find(c => c.name === selectedCollege);
  const selectedBuildingData = selectedCollegeData?.buildings.find(b => b.number === selectedBuilding);

  useEffect(() => {
    if (walkingAnimation) {
      const interval = setInterval(() => {
        setPathProgress(prev => {
          if (prev >= 100) {
            setWalkingAnimation(false);
            return 100;
          }
          return prev + 2;
        });
      }, 100);

      return () => clearInterval(interval);
    }
  }, [walkingAnimation]);

  const handleSearch = () => {
    if (selectedCollege) {
      setShowMap(true);
      setWalkingAnimation(true);
      setPathProgress(0);
    }
  };

  const getDirectionInstructions = () => {
    if (!selectedCollege) return "";
    
    let instructions = `Navigate to ${selectedCollege}`;
    
    if (selectedBuilding && selectedBuildingData) {
      instructions += ` - ${selectedBuildingData.name}`;
    }
    
    if (selectedRoom) {
      instructions += ` - Room ${selectedRoom}`;
    }
    
    return instructions;
  };

  const getDestinationCoords = () => {
    if (selectedBuildingData) {
      return { x: selectedBuildingData.x, y: selectedBuildingData.y };
    }
    if (selectedCollegeData) {
      return { x: selectedCollegeData.centerX, y: selectedCollegeData.centerY };
    }
    return START_POINT;
  };

  const generatePath = () => {
    const destination = getDestinationCoords();
    const pathPoints = [];
    
    // Create curved path with multiple points
    const steps = 20;
    for (let i = 0; i <= steps; i++) {
      const progress = i / steps;
      const x = START_POINT.x + (destination.x - START_POINT.x) * progress + Math.sin(progress * Math.PI) * 30;
      const y = START_POINT.y + (destination.y - START_POINT.y) * progress;
      pathPoints.push({ x, y });
    }
    
    return pathPoints;
  };

  const Building3D = ({ building, college, isTarget = false }: any) => {
    const { x, y, z, name } = building;
    const height = z;
    const width = 40;
    const depth = 30;

    return (
      <g key={`${college.name}-${building.number}`}>
        {/* Building shadow */}
        <ellipse
          cx={x + 15}
          cy={y + height + 15}
          rx={width * 0.6}
          ry={depth * 0.3}
          fill="rgba(0,0,0,0.2)"
          className="animate-pulse"
        />
        
        {/* Building base (front face) */}
        <rect
          x={x}
          y={y}
          width={width}
          height={height}
          fill={`${college.color === 'orange' ? '#fed7aa' : 
                 college.color === 'purple' ? '#e9d5ff' :
                 college.color === 'green' ? '#bbf7d0' :
                 college.color === 'red' ? '#fecaca' : '#dbeafe'}`}
          stroke={`${college.color === 'orange' ? '#ea580c' : 
                    college.color === 'purple' ? '#9333ea' :
                    college.color === 'green' ? '#16a34a' :
                    college.color === 'red' ? '#dc2626' : '#2563eb'}`}
          strokeWidth="2"
          className={`transition-all duration-500 ${isTarget ? 'animate-pulse' : ''}`}
        />

        {/* Building top (3D effect) */}
        <polygon
          points={`${x},${y} ${x + 15},${y - 15} ${x + width + 15},${y - 15} ${x + width},${y}`}
          fill={`${college.color === 'orange' ? '#fdba74' : 
                 college.color === 'purple' ? '#d8b4fe' :
                 college.color === 'green' ? '#86efac' :
                 college.color === 'red' ? '#f87171' : '#93c5fd'}`}
          stroke={`${college.color === 'orange' ? '#ea580c' : 
                    college.color === 'purple' ? '#9333ea' :
                    college.color === 'green' ? '#16a34a' :
                    college.color === 'red' ? '#dc2626' : '#2563eb'}`}
          strokeWidth="2"
        />

        {/* Building right side (3D effect) */}
        <polygon
          points={`${x + width},${y} ${x + width + 15},${y - 15} ${x + width + 15},${y + height - 15} ${x + width},${y + height}`}
          fill={`${college.color === 'orange' ? '#fb923c' : 
                 college.color === 'purple' ? '#c084fc' :
                 college.color === 'green' ? '#4ade80' :
                 college.color === 'red' ? '#ef4444' : '#60a5fa'}`}
          stroke={`${college.color === 'orange' ? '#ea580c' : 
                    college.color === 'purple' ? '#9333ea' :
                    college.color === 'green' ? '#16a34a' :
                    college.color === 'red' ? '#dc2626' : '#2563eb'}`}
          strokeWidth="2"
        />

        {/* Windows */}
        {Array.from({ length: Math.floor(height / 25) }, (_, floor) => (
          <g key={floor}>
            {Array.from({ length: 3 }, (_, window) => (
              <rect
                key={window}
                x={x + 8 + window * 10}
                y={y + 15 + floor * 25}
                width="6"
                height="8"
                fill="#87ceeb"
                stroke="#4682b4"
                strokeWidth="1"
                className="animate-pulse"
                style={{ animationDelay: `${(floor + window) * 0.2}s` }}
              />
            ))}
          </g>
        ))}

        {/* Building label */}
        <text
          x={x + width / 2}
          y={y + height + 25}
          textAnchor="middle"
          className="text-xs font-medium fill-gray-700"
        >
          {building.number}
        </text>

        {/* Target marker for selected building */}
        {isTarget && (
          <g>
            <circle
              cx={x + width / 2}
              cy={y - 25}
              r="12"
              fill="#ef4444"
              className="animate-bounce"
            />
            <MapPin className="w-4 h-4" x={x + width / 2 - 8} y={y - 33} fill="white" />
          </g>
        )}
      </g>
    );
  };

  const AnimatedWalkingPath = () => {
    const pathPoints = generatePath();
    const currentPointIndex = Math.floor((pathProgress / 100) * (pathPoints.length - 1));
    const currentPoint = pathPoints[currentPointIndex] || START_POINT;

    return (
      <g>
        {/* Full path (dashed line) */}
        <path
          d={`M ${pathPoints.map(p => `${p.x},${p.y}`).join(' L ')}`}
          stroke="#0ea5e9"
          strokeWidth="3"
          fill="none"
          strokeDasharray="10,5"
          opacity="0.6"
        />

        {/* Animated path (solid line showing progress) */}
        <path
          d={`M ${pathPoints.slice(0, currentPointIndex + 1).map(p => `${p.x},${p.y}`).join(' L ')}`}
          stroke="#0f172a"
          strokeWidth="4"
          fill="none"
          className="drop-shadow-lg"
        />

        {/* Walking person icon */}
        {walkingAnimation && (
          <g transform={`translate(${currentPoint.x - 10}, ${currentPoint.y - 10})`}>
            <circle r="8" fill="#3b82f6" className="animate-pulse" />
            <text
              x="0"
              y="2"
              textAnchor="middle"
              className="text-xs fill-white font-bold"
            >
              🚶
            </text>
          </g>
        )}

        {/* Progress dots along the path */}
        {pathPoints.map((point, index) => (
          <circle
            key={index}
            cx={point.x}
            cy={point.y}
            r="3"
            fill={index <= currentPointIndex ? "#10b981" : "#d1d5db"}
            className="transition-all duration-300"
          />
        ))}
      </g>
    );
  };

  return (
    <div className="min-h-screen" style={{ 
      background: 'linear-gradient(180deg, #f0f9ff 0%, #e0f2fe 50%, #bae6fd 100%)' 
    }}>
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2 bg-white/80 backdrop-blur-sm hover:bg-white"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </Button>
          </div>
          <h1 className="text-4xl font-bold text-[#0D2E57] flex items-center space-x-4">
            <Map className="h-10 w-10" />
            <span>3D University Map</span>
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Search Form */}
          <div className="lg:col-span-2">
            <Card className="bg-white/90 backdrop-blur-sm border-white/50 shadow-xl">
              <CardHeader>
                <CardTitle className="text-xl text-[#0D2E57] flex items-center space-x-3">
                  <Search className="h-6 w-6" />
                  <span>Navigation Search</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* College Selection */}
                <div className="space-y-2">
                  <Label className="block flex items-center">
                    <span>Select Destination College</span>
                    <span className="text-red-500 ml-1">*</span>
                  </Label>
                  <Select value={selectedCollege} onValueChange={(value) => {
                    setSelectedCollege(value);
                    setSelectedBuilding("");
                    setSelectedRoom("");
                    setShowMap(false);
                    setWalkingAnimation(false);
                    setPathProgress(0);
                  }}>
                    <SelectTrigger className="w-full bg-white/80">
                      <SelectValue placeholder="Choose your destination college" />
                    </SelectTrigger>
                    <SelectContent>
                      {collegesAndBuildings.map((college) => (
                        <SelectItem key={college.name} value={college.name}>
                          🏛️ {college.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Building Selection */}
                <div className="space-y-2">
                  <Label className="block">
                    Specific Building (Optional)
                  </Label>
                  <Select 
                    value={selectedBuilding} 
                    onValueChange={(value) => {
                      setSelectedBuilding(value);
                      setSelectedRoom("");
                    }}
                    disabled={!selectedCollege}
                  >
                    <SelectTrigger className="w-full bg-white/80">
                      <SelectValue placeholder="Choose specific building" />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedCollegeData?.buildings.map((building) => (
                        <SelectItem key={building.number} value={building.number}>
                          🏢 {building.number} - {building.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Room Selection */}
                <div className="space-y-2">
                  <Label className="block">
                    Room Number (Optional)
                  </Label>
                  <Select 
                    value={selectedRoom} 
                    onValueChange={setSelectedRoom}
                    disabled={!selectedBuilding}
                  >
                    <SelectTrigger className="w-full bg-white/80">
                      <SelectValue placeholder="Choose room" />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedBuildingData?.rooms.map((room) => (
                        <SelectItem key={room} value={room}>
                          🚪 {room}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Search Button */}
                <Button 
                  onClick={handleSearch}
                  disabled={!selectedCollege}
                  className="w-full bg-gradient-to-r from-[#0D2E57] to-[#1e40af] hover:from-[#1e40af] hover:to-[#0D2E57] text-white py-4 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed shadow-lg transition-all duration-300"
                >
                  <span className="flex items-center justify-center space-x-2">
                    <Route className="h-5 w-5" />
                    <span>Start 3D Navigation</span>
                  </span>
                </Button>

                {/* Instructions */}
                <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-4 rounded-lg border border-blue-200">
                  <div className="flex items-start space-x-3">
                    <Compass className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-blue-800 font-medium mb-1">
                        3D Navigation Features:
                      </p>
                      <ul className="text-blue-700 text-sm leading-relaxed space-y-1">
                        <li>• View buildings in 3D perspective</li>
                        <li>• Animated walking path to destination</li>
                        <li>• Real-time progress tracking</li>
                        <li>• Interactive building details</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 3D Map Display */}
          <div className="lg:col-span-3">
            <Card className="h-full bg-white/90 backdrop-blur-sm border-white/50 shadow-xl">
              <CardHeader>
                <CardTitle className="text-xl text-[#0D2E57] flex items-center space-x-3">
                  <Building className="h-6 w-6" />
                  <span>3D Campus View</span>
                  {walkingAnimation && (
                    <div className="flex items-center space-x-2 text-sm text-green-600">
                      <Clock className="h-4 w-4" />
                      <span>Navigating... {Math.round(pathProgress)}%</span>
                    </div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {showMap && selectedCollege ? (
                  <div className="space-y-6">
                    {/* Route Information */}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                      <div className="flex items-center space-x-3">
                        <Navigation className="h-6 w-6 text-green-600" />
                        <div className="flex-1">
                          <h3 className="font-medium text-green-800">
                            3D Route to destination:
                          </h3>
                          <p className="text-green-700 mt-1">
                            {getDirectionInstructions()}
                          </p>
                        </div>
                        <div className="text-right text-sm text-green-600">
                          <div>Distance: ~{Math.floor(Math.sqrt(Math.pow(getDestinationCoords().x - START_POINT.x, 2) + Math.pow(getDestinationCoords().y - START_POINT.y, 2)) / 10)}0m</div>
                          <div>Time: ~{Math.ceil(Math.sqrt(Math.pow(getDestinationCoords().x - START_POINT.x, 2) + Math.pow(getDestinationCoords().y - START_POINT.y, 2)) / 50)} min</div>
                        </div>
                      </div>
                    </div>

                    {/* 3D Campus Map */}
                    <div className="relative bg-gradient-to-br from-green-100 via-blue-50 to-green-100 border-2 border-gray-300 rounded-xl overflow-hidden" style={{ height: '600px' }}>
                      <svg className="w-full h-full" viewBox="0 0 500 450">
                        {/* Campus Background */}
                        <defs>
                          <pattern id="grass" patternUnits="userSpaceOnUse" width="20" height="20">
                            <rect width="20" height="20" fill="#dcfce7"/>
                            <circle cx="5" cy="5" r="1" fill="#16a34a" opacity="0.3"/>
                            <circle cx="15" cy="15" r="1" fill="#16a34a" opacity="0.2"/>
                          </pattern>
                          <linearGradient id="roadGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#6b7280" />
                            <stop offset="100%" stopColor="#4b5563" />
                          </linearGradient>
                        </defs>

                        {/* Grass background */}
                        <rect width="100%" height="100%" fill="url(#grass)" />

                        {/* Roads */}
                        <rect x="0" y="200" width="500" height="20" fill="url(#roadGradient)" />
                        <rect x="240" y="0" width="20" height="450" fill="url(#roadGradient)" />

                        {/* Road markings */}
                        <line x1="0" y1="210" x2="500" y2="210" stroke="white" strokeWidth="2" strokeDasharray="20,10" />
                        <line x1="250" y1="0" x2="250" y2="450" stroke="white" strokeWidth="2" strokeDasharray="20,10" />

                        {/* Trees and landscaping */}
                        {[...Array(15)].map((_, i) => (
                          <g key={i}>
                            <circle 
                              cx={80 + (i * 30) % 400} 
                              cy={50 + (i * 40) % 350} 
                              r="8" 
                              fill="#22c55e" 
                              opacity="0.7"
                            />
                            <rect 
                              x={77 + (i * 30) % 400} 
                              y={55 + (i * 40) % 350} 
                              width="6" 
                              height="8" 
                              fill="#92400e"
                            />
                          </g>
                        ))}

                        {/* Starting point (University Entrance) */}
                        <g>
                          <rect x={START_POINT.x - 20} y={START_POINT.y - 15} width="40" height="30" fill="#f59e0b" stroke="#d97706" strokeWidth="2" />
                          <polygon points={`${START_POINT.x - 20},${START_POINT.y - 15} ${START_POINT.x - 5},${START_POINT.y - 30} ${START_POINT.x + 35},${START_POINT.y - 30} ${START_POINT.x + 20},${START_POINT.y - 15}`} fill="#fbbf24" stroke="#d97706" strokeWidth="2" />
                          <text x={START_POINT.x} y={START_POINT.y + 25} textAnchor="middle" className="text-xs font-bold fill-amber-800">
                            🚪 ENTRANCE
                          </text>
                          <circle cx={START_POINT.x} cy={START_POINT.y} r="6" fill="#ef4444" className="animate-pulse" />
                        </g>

                        {/* Render all college buildings in 3D */}
                        {collegesAndBuildings.map((college) =>
                          college.buildings.map((building) => (
                            <Building3D
                              key={`${college.name}-${building.number}`}
                              building={building}
                              college={college}
                              isTarget={selectedBuildingData?.number === building.number || (!selectedBuilding && college.name === selectedCollege)}
                            />
                          ))
                        )}

                        {/* Animated Walking Path */}
                        {showMap && <AnimatedWalkingPath />}

                        {/* Campus Labels */}
                        {collegesAndBuildings.map((college) => (
                          <text
                            key={college.name}
                            x={college.centerX}
                            y={college.centerY - 60}
                            textAnchor="middle"
                            className="text-sm font-bold fill-slate-700"
                            style={{ filter: 'drop-shadow(1px 1px 2px rgba(255,255,255,0.8))' }}
                          >
                            {college.name.split(' ').slice(0, 2).join(' ')}
                          </text>
                        ))}
                      </svg>

                      {/* 3D Compass */}
                      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-3 rounded-full shadow-lg border">
                        <div className="w-12 h-12 relative">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Compass className="h-6 w-6 text-blue-600" />
                          </div>
                          <div className="absolute top-0 left-1/2 w-1 h-4 bg-red-500 transform -translate-x-1/2 rounded-full"></div>
                          <span className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs font-bold text-red-600">N</span>
                        </div>
                      </div>

                      {/* Progress indicator */}
                      {walkingAnimation && (
                        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg border">
                          <div className="flex items-center space-x-3">
                            <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-gradient-to-r from-blue-500 to-green-500 transition-all duration-300 ease-out"
                                style={{ width: `${pathProgress}%` }}
                              ></div>
                            </div>
                            <span className="text-sm font-medium text-gray-700">{Math.round(pathProgress)}%</span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Building Details */}
                    {selectedBuilding && selectedBuildingData && (
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
                        <h4 className="font-medium text-blue-800 mb-2 flex items-center space-x-2">
                          <Building className="h-4 w-4" />
                          <span>Building Information:</span>
                        </h4>
                        <div className="space-y-1">
                          <p className="text-blue-700 text-sm">
                            🏢 Building {selectedBuilding} - {selectedBuildingData.name}
                          </p>
                          <p className="text-blue-700 text-sm">
                            📐 Dimensions: {selectedBuildingData.z}m height
                          </p>
                          {selectedRoom && (
                            <p className="text-blue-700 text-sm">
                              🚪 Target Room: {selectedRoom}
                            </p>
                          )}
                          <p className="text-blue-600 text-xs mt-2">
                            💡 The building is highlighted in 3D view with animated marker
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-96 text-gray-500">
                    <div className="relative mb-6">
                      <Map className="h-20 w-20 text-gray-400" />
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm">3D</span>
                      </div>
                    </div>
                    <p className="text-center text-lg font-medium">
                      Select your destination to view 3D campus map
                    </p>
                    <p className="text-center text-sm mt-2 max-w-md">
                      Experience our interactive 3D campus with realistic buildings, animated walking paths, and real-time navigation
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}