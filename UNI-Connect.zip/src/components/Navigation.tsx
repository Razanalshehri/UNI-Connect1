import { Button } from "./ui/button";
import { BookOpen, Calendar, GraduationCap, Home, MapPin, User } from "lucide-react";

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
}

export function Navigation({ currentView, onViewChange }: NavigationProps) {
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "courses", label: "Courses", icon: BookOpen },
    { id: "schedule", label: "Schedule", icon: Calendar },
    { id: "grades", label: "Grades", icon: GraduationCap },
    { id: "events", label: "Events", icon: MapPin },
    { id: "profile", label: "Profile", icon: User },
  ];

  return (
    <nav className="bg-card border-b border-border p-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <GraduationCap className="h-8 w-8 text-primary" />
          <h1 className="text-xl font-semibold">UniApp</h1>
        </div>
        
        <div className="flex space-x-2 overflow-x-auto">
          {navItems.map(({ id, label, icon: Icon }) => (
            <Button
              key={id}
              variant={currentView === id ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewChange(id)}
              className="flex items-center space-x-2 whitespace-nowrap"
            >
              <Icon className="h-4 w-4" />
              <span className="hidden sm:inline">{label}</span>
            </Button>
          ))}
        </div>
      </div>
    </nav>
  );
}