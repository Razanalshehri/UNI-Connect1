import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  BarChart3, 
  Clock, 
  Users, 
  TrendingUp, 
  CheckCircle2, 
  Circle,
  Plus,
  Share2,
  Calendar
} from "lucide-react";

export function Polls() {
  const [votedPolls, setVotedPolls] = useState<Record<number, number>>({});

  const activePolls = [
    {
      id: 1,
      title: "What type of campus events would you like to see more of?",
      description: "Help us plan better events for the student community",
      category: "Student Life",
      endDate: "2025-09-15",
      totalVotes: 287,
      options: [
        { id: 1, text: "Tech Workshops & Coding Bootcamps", votes: 89 },
        { id: 2, text: "Social Meetups & Networking", votes: 67 },
        { id: 3, text: "Career Fairs & Industry Talks", votes: 98 },
        { id: 4, text: "Sports & Fitness Activities", votes: 33 }
      ],
      isActive: true,
      createdBy: "Student Affairs"
    },
    {
      id: 2,
      title: "Preferred study hours for library extension?",
      description: "We're considering extending library hours based on demand",
      category: "Academic",
      endDate: "2025-09-10",
      totalVotes: 156,
      options: [
        { id: 1, text: "24/7 Access", votes: 78 },
        { id: 2, text: "Until 2 AM on weekdays", votes: 45 },
        { id: 3, text: "Until midnight", votes: 23 },
        { id: 4, text: "Current hours are fine", votes: 10 }
      ],
      isActive: true,
      createdBy: "Library Services"
    },
    {
      id: 3,
      title: "Best location for new food truck on campus?",
      description: "Vote for where you'd like to see the new food truck stationed",
      category: "Dining",
      endDate: "2025-09-12",
      totalVotes: 203,
      options: [
        { id: 1, text: "Near Student Center", votes: 87 },
        { id: 2, text: "Science Building Plaza", votes: 54 },
        { id: 3, text: "Library Courtyard", votes: 39 },
        { id: 4, text: "Main Quad", votes: 23 }
      ],
      isActive: true,
      createdBy: "Dining Services"
    }
  ];

  const recentPolls = [
    {
      id: 4,
      title: "Preferred payment method for campus services?",
      category: "Administrative",
      endDate: "2025-08-30",
      totalVotes: 445,
      winner: "Mobile payments",
      isActive: false
    },
    {
      id: 5,
      title: "Most needed improvement in dorm facilities?",
      category: "Housing",
      endDate: "2025-08-25",
      totalVotes: 312,
      winner: "Better WiFi",
      isActive: false
    }
  ];

  const handleVote = (pollId: number, optionId: number) => {
    setVotedPolls(prev => ({ ...prev, [pollId]: optionId }));
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Student Life": return "bg-blue-100 text-blue-800 border-blue-200";
      case "Academic": return "bg-green-100 text-green-800 border-green-200";
      case "Dining": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Housing": return "bg-purple-100 text-purple-800 border-purple-200";
      case "Administrative": return "bg-gray-100 text-gray-800 border-gray-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const calculatePercentage = (votes: number, total: number) => {
    return total > 0 ? Math.round((votes / total) * 100) : 0;
  };

  const getTimeRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    
    if (days > 1) return `${days} days left`;
    if (days === 1) return "1 day left";
    return "Ending soon";
  };

  return (
    <div className="pb-20 space-y-6">
      {/* Header */}
      <div className="px-4 pt-4">
        <div className="flex items-center justify-between mb-2">
          <h1>Campus Polls</h1>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Create Poll
          </Button>
        </div>
        <p className="text-muted-foreground text-sm">
          Your voice matters! Participate in polls to shape campus decisions.
        </p>
      </div>

      {/* Stats */}
      <div className="px-4">
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{activePolls.length}</div>
              <div className="text-xs text-muted-foreground">Active Polls</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">
                {activePolls.reduce((sum, poll) => sum + poll.totalVotes, 0)}
              </div>
              <div className="text-xs text-muted-foreground">Total Votes</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">
                {Object.keys(votedPolls).length}
              </div>
              <div className="text-xs text-muted-foreground">Your Votes</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Active Polls */}
      <div className="px-4">
        <h2 className="mb-4">Active Polls</h2>
        <div className="space-y-4">
          {activePolls.map((poll) => {
            const userVote = votedPolls[poll.id];
            const hasVoted = userVote !== undefined;

            return (
              <Card key={poll.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <Badge className={getCategoryColor(poll.category)}>
                          {poll.category}
                        </Badge>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Clock className="h-3 w-3 mr-1" />
                          {getTimeRemaining(poll.endDate)}
                        </div>
                      </div>
                      <CardTitle className="text-base leading-tight">{poll.title}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{poll.description}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <Users className="h-3 w-3 mr-1" />
                        {poll.totalVotes} votes
                      </div>
                      <span>by {poll.createdBy}</span>
                    </div>
                    {hasVoted && (
                      <div className="flex items-center text-green-600">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Voted
                      </div>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  {poll.options.map((option) => {
                    const percentage = calculatePercentage(option.votes, poll.totalVotes);
                    const isSelected = userVote === option.id;
                    
                    return (
                      <div key={option.id} className="space-y-2">
                        <button
                          onClick={() => !hasVoted && handleVote(poll.id, option.id)}
                          disabled={hasVoted}
                          className={`w-full text-left p-3 rounded-lg border transition-all ${
                            hasVoted
                              ? isSelected
                                ? "border-primary bg-primary/10"
                                : "border-border bg-muted/50"
                              : "border-border hover:border-primary hover:bg-primary/5"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              {hasVoted ? (
                                isSelected ? (
                                  <CheckCircle2 className="h-4 w-4 text-primary" />
                                ) : (
                                  <Circle className="h-4 w-4 text-muted-foreground" />
                                )
                              ) : (
                                <Circle className="h-4 w-4 text-muted-foreground" />
                              )}
                              <span className="text-sm font-medium">{option.text}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {hasVoted ? `${percentage}%` : `${option.votes} votes`}
                            </span>
                          </div>
                          
                          {hasVoted && (
                            <div className="w-full bg-muted rounded-full h-1.5">
                              <div
                                className={`h-1.5 rounded-full transition-all duration-500 ${
                                  isSelected ? "bg-primary" : "bg-primary/60"
                                }`}
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          )}
                        </button>
                      </div>
                    );
                  })}
                  
                  {!hasVoted && (
                    <div className="text-center pt-2">
                      <p className="text-xs text-muted-foreground">
                        Click on an option to cast your vote
                      </p>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3 mr-1" />
                      Ends {poll.endDate}
                    </div>
                    <Button variant="ghost" size="sm">
                      <Share2 className="h-3 w-3 mr-1" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Recent Results */}
      <div className="px-4">
        <h2 className="mb-4">Recent Results</h2>
        <div className="space-y-3">
          {recentPolls.map((poll) => (
            <Card key={poll.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <Badge className={getCategoryColor(poll.category)}>
                        {poll.category}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Completed
                      </Badge>
                    </div>
                    <h3 className="font-medium">{poll.title}</h3>
                    <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                      <div className="flex items-center">
                        <Users className="h-3 w-3 mr-1" />
                        {poll.totalVotes} votes
                      </div>
                      <div className="flex items-center">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        Winner: {poll.winner}
                      </div>
                      <span>Ended {poll.endDate}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    View Results
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Create Poll CTA */}
      <div className="px-4">
        <Card>
          <CardContent className="p-6 text-center">
            <BarChart3 className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="font-medium mb-2">Create Your Own Poll</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Have a question for the campus community? Create a poll and get insights from your peers.
            </p>
            <Button className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Create New Poll
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}