import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { TrendingUp, TrendingDown, BookOpen, Award } from "lucide-react";

export function Grades() {
  const currentCourses = [
    {
      id: 1,
      code: "CS 101",
      name: "Intro to Computer Science",
      currentGrade: 87.5,
      letterGrade: "A-",
      credits: 4,
      assignments: [
        { name: "Midterm Exam", grade: 92, weight: 30, date: "2025-08-15" },
        { name: "Programming Project 1", grade: 85, weight: 20, date: "2025-08-22" },
        { name: "Quiz 1", grade: 88, weight: 10, date: "2025-08-29" },
        { name: "Quiz 2", grade: 91, weight: 10, date: "2025-09-01" }
      ],
      trend: "up"
    },
    {
      id: 2,
      code: "MATH 201",
      name: "Calculus II",
      currentGrade: 82.3,
      letterGrade: "B+",
      credits: 4,
      assignments: [
        { name: "Midterm Exam", grade: 78, weight: 35, date: "2025-08-16" },
        { name: "Problem Set 1", grade: 85, weight: 15, date: "2025-08-20" },
        { name: "Problem Set 2", grade: 87, weight: 15, date: "2025-08-27" },
        { name: "Quiz 1", grade: 84, weight: 10, date: "2025-09-01" }
      ],
      trend: "up"
    },
    {
      id: 3,
      code: "PHYS 150",
      name: "General Physics I",
      currentGrade: 76.8,
      letterGrade: "B",
      credits: 4,
      assignments: [
        { name: "Lab Report 1", grade: 82, weight: 20, date: "2025-08-18" },
        { name: "Midterm Exam", grade: 74, weight: 30, date: "2025-08-25" },
        { name: "Lab Report 2", grade: 79, weight: 20, date: "2025-09-01" }
      ],
      trend: "down"
    },
    {
      id: 4,
      code: "ENG 102",
      name: "English Literature",
      currentGrade: 93.2,
      letterGrade: "A",
      credits: 3,
      assignments: [
        { name: "Essay 1", grade: 95, weight: 25, date: "2025-08-20" },
        { name: "Midterm Exam", grade: 91, weight: 25, date: "2025-08-26" },
        { name: "Discussion Posts", grade: 94, weight: 20, date: "2025-09-01" }
      ],
      trend: "up"
    }
  ];

  const semesterStats = {
    currentGPA: 3.74,
    previousGPA: 3.52,
    totalCredits: 15,
    completedCredits: 45,
    degreeProgress: 28
  };

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return "text-green-600";
    if (grade >= 80) return "text-blue-600";
    if (grade >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getLetterGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return "bg-green-100 text-green-800 border-green-200";
    if (grade.startsWith('B')) return "bg-blue-100 text-blue-800 border-blue-200";
    if (grade.startsWith('C')) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    return "bg-red-100 text-red-800 border-red-200";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Grades & Progress</h1>
          <p className="text-muted-foreground">Track your academic performance and progress.</p>
        </div>
        <Badge variant="secondary">Fall 2025</Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Current GPA</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{semesterStats.currentGPA}</div>
            <p className="text-xs text-green-600">
              +{(semesterStats.currentGPA - semesterStats.previousGPA).toFixed(2)} from last semester
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Credits This Semester</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{semesterStats.totalCredits}</div>
            <p className="text-xs text-muted-foreground">
              {semesterStats.completedCredits} total credits earned
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Degree Progress</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{semesterStats.degreeProgress}%</div>
            <Progress value={semesterStats.degreeProgress} className="h-2 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentCourses.length}</div>
            <p className="text-xs text-muted-foreground">
              Currently enrolled
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h2>Current Courses</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {currentCourses.map((course) => (
            <Card key={course.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <span>{course.code}</span>
                      <Badge variant="outline">{course.credits} credits</Badge>
                    </CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">{course.name}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getLetterGradeColor(course.letterGrade)}>
                      {course.letterGrade}
                    </Badge>
                    {course.trend === "up" ? (
                      <TrendingUp className="h-4 w-4 text-green-600" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-600" />
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Current Grade</span>
                  <span className={`font-bold ${getGradeColor(course.currentGrade)}`}>
                    {course.currentGrade}%
                  </span>
                </div>
                <Progress value={course.currentGrade} className="h-2" />

                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Recent Assignments</h4>
                  {course.assignments.slice(-3).map((assignment, index) => (
                    <div key={index} className="flex justify-between items-center p-2 bg-secondary/50 rounded text-sm">
                      <div>
                        <span className="font-medium">{assignment.name}</span>
                        <p className="text-xs text-muted-foreground">{assignment.date}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-muted-foreground">{assignment.weight}%</span>
                        <span className={getGradeColor(assignment.grade)}>
                          {assignment.grade}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Grade Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">1</div>
              <div className="text-sm text-green-700">A Grades</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">2</div>
              <div className="text-sm text-blue-700">B Grades</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-600">0</div>
              <div className="text-sm text-gray-700">C Grades</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-600">0</div>
              <div className="text-sm text-gray-700">Below C</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}